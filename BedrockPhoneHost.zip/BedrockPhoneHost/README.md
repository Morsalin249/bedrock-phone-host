# Bedrock Phone Host

Android app that turns your phone into a Minecraft **Bedrock** server (Anvil-MC / Aternos style).
You type a Bedrock version, press Start, and the app installs and runs the official Bedrock Dedicated Server,
shows join addresses (Playit.gg tunnel, Wi-Fi, IPv6), a live player list, a console, server settings and addon import.

## How it works
Android is ARM; the official server is x86_64 Linux. The app downloads (first start only):
proot -> Debian arm64 rootfs -> box64 + x86_64 libs -> Bedrock Dedicated Server (from minecraft.net) -> Playit agent.
Everything runs inside a foreground service. All download links are in `Config.kt`.

## Build without a PC
1. Create a GitHub repo and upload this folder.
2. Actions tab -> "Build APK" runs automatically (or run it manually).
3. Download the `BedrockPhoneHost-debug-apk` artifact, unzip, install the APK (allow unknown sources).

## Build with Android Studio
Open this folder, let Gradle sync, press Run / Build APK.

## Notes
- targetSdk is 28 on purpose (Android 10+ blocks running downloaded binaries otherwise). Sideload only, not Play Store.
- Needs ~2 GB free storage, arm64 phone with 4 GB+ RAM recommended.
- Disable battery optimization for the app, and keep the phone cool/plugged in.
- Players must use the same Minecraft version as the server.

## v1.1 additions
- Import / export worlds (`.mcworld`) on the Content tab.
- Performance profiles (Low / Medium / High) in Settings; Bedrock has no RAM setting, these tune view/tick distance, players and threads.
- Storage card on Home, and an optional "auto-stop if world exceeds X MB" limit.

## v1.2
- Debian root filesystem is now pulled from the Docker Hub registry (the old GitHub link 404'd).

## v1.3
- Fixed signing key: future builds install over the old app and keep your downloaded Linux runtime (uninstall once when moving to this version).
- Setup now prints a diagnostic test and traces each install command in the Console tab.

## v1.4
- Settings: every Bedrock server option now has a proper control (dropdowns, switches, number fields).
- Settings save automatically and are stored in the app, then written to server.properties on every Start (fixes values disappearing).

## v1.5
- Setup now auto-tests proot 5.4.0 / 5.3.0 and Debian trixie / bullseye and keeps the first combination that can start a Linux shell, printing diagnostics if none can.

## v2.0 (Termux version)
Android blocked running Linux from inside the app on the test phone, so the server now runs in Termux:
- `app/src/main/assets/panel.py` is the backend. The app sends it to Termux (RUN_COMMAND) and talks to it on 127.0.0.1:8765 with a private token.
- The app is the Aternos-style front end: Server, Console, Players, Options (all Bedrock options as switches/dropdowns), Content (addons, worlds).
- First run: install Termux from F-Droid, follow the 4 steps on the app's setup screen.

## v2.1
- Commands: console and player buttons now report problems in the Console tab ("server is not running"...), a leading `/` is accepted, Enter sends, `stop` updates the status, and stopping kills the whole server process tree.
- No longer forces `transport=raknet` (NetherNet is the default and only supported transport since Bedrock 26.50). Only the settings you changed are written to server.properties.
- Settings screen reorganised: tabs (General / Players / Network / World / Advanced), collapsible groups, a search box and an Advanced switch. Option list checked against the Bedrock 1.26.52 server.properties; removed keys that no longer exist or are Java-only (`op-permission-level`, `level-type`, `server-authoritative-movement`, `correct-player-movement`, the old `player-movement-*` thresholds, `emit-server-telemetry`, `disable-persona`) and added the current ones.
- Tunnels: add any number of NetherNet tunnels (name, public address, optional start command run in Termux with the server). Playit is optional and off by default.
- Players tab: shows the real allowlist (current Bedrock servers ship with `allow-list=true`, which locks everyone out until players are added).
- "Start backend" waits for an old backend to shut down before starting the new one.
- Version: type `latest` to install the newest server; a 404 now tells you the newest build number.

## v2.2
- Multiple servers: pick the server in the top bar (name ▾). Each server has its own folder, world, add-ons, port, console, players and tunnels. New servers get the next free port automatically (19134, 19136, ...); change it in Settings > Network. The first server keeps its old folder and data.
- Tunnels are per server. Use `{port}` in a tunnel's start command to insert that server's port.
- Software: Preview, Latest and the 3 previous release lines, refreshed every time the app opens (Refresh button too). Preview and Latest come from Mojang's download API, old ones from the community archive Bedrock-OSS/BDS-Versions. The supported-Minecraft-versions line appears only when Mojang's protocol docs list it.
- Several servers share one Debian/box64 install, but each one needs its own ~300 MB of server files and a lot of CPU/RAM.
