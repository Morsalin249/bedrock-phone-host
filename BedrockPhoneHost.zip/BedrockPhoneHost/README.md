# Bedrock Phone Host

Android app that turns your phone into a Minecraft **Bedrock** server (Anvil-MC / Aternos style).
You type a Bedrock version, press Start, and the app installs and runs the official Bedrock Dedicated Server,
shows join addresses (Playit.gg tunnel, Wi-Fi, IPv6), a live player list, a console, server settings and addon import.

## How it works
Android is ARM; the official server is x86_64 Linux. The app downloads (first start only):
proot -> Debian arm64 rootfs -> box64 + x86_64 libs -> Bedrock Dedicated Server (from minecraft.net) -> Playit agent.
Everything runs inside a foreground service. All download links are in `Config.kt`.

## Build without a PC
1. Create a GitHub repo and upload this folder.
2. Actions tab -> "Build APK" runs automatically (or run it manually).
3. Download the `BedrockPhoneHost-debug-apk` artifact, unzip, install the APK (allow unknown sources).

## Build with Android Studio
Open this folder, let Gradle sync, press Run / Build APK.

## Notes
- targetSdk is 28 on purpose (Android 10+ blocks running downloaded binaries otherwise). Sideload only, not Play Store.
- Needs ~2 GB free storage, arm64 phone with 4 GB+ RAM recommended.
- Disable battery optimization for the app, and keep the phone cool/plugged in.
- Players must use the same Minecraft version as the server.

## v1.1 additions
- Import / export worlds (`.mcworld`) on the Content tab.
- Performance profiles (Low / Medium / High) in Settings; Bedrock has no RAM setting, these tune view/tick distance, players and threads.
- Storage card on Home, and an optional "auto-stop if world exceeds X MB" limit.

## v1.2
- Debian root filesystem is now pulled from the Docker Hub registry (the old GitHub link 404'd).
