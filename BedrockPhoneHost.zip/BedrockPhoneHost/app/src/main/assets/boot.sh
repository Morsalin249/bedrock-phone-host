# Started by the Android app through Termux RUN_COMMAND:
#   bash -c "<this script>" _ <panel.py text> <token>
export PATH=/data/data/com.termux/files/usr/bin:$PATH
export PREFIX=/data/data/com.termux/files/usr
[ -n "$HOME" ] || export HOME=/data/data/com.termux/files/home
mkdir -p "$HOME/bedrock-host"
cd "$HOME/bedrock-host" || exit 1
printf '%s' "$1" > panel.py.new && mv panel.py.new panel.py
if ! command -v python >/dev/null 2>&1; then yes | pkg install -y python; fi
if ! command -v proot-distro >/dev/null 2>&1; then yes | pkg install -y proot-distro; fi
pkill -f "^python panel.py" 2>/dev/null && sleep 2
termux-wake-lock 2>/dev/null
exec python panel.py "$2" >> panel.log 2>&1
