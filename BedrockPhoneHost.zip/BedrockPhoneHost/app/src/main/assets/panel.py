#!/usr/bin/env python3
"""Bedrock Phone Host backend. Runs inside Termux and is controlled by the Android app
over http://127.0.0.1:8765 (token protected). Standard library only."""
import os, sys, re, json, time, shutil, shlex, socket, signal, zipfile, threading, subprocess, tempfile
import urllib.request, urllib.parse
from collections import deque
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

PORT = int(os.environ.get("PANEL_PORT", "8765"))
FAKE = os.environ.get("PANEL_FAKE") == "1"          # test mode, no Linux needed
HOME = os.environ.get("PANEL_HOME") or os.path.expanduser("~/bedrock-host")
PREFIX = os.environ.get("PREFIX", "/data/data/com.termux/files/usr")
DISTRO_BASE = os.path.join(PREFIX, "var/lib/proot-distro")


def find_rootfs():
    """proot-distro keeps the Debian folder in different places depending on its version."""
    for c in (os.path.join(DISTRO_BASE, "containers", "debian"), os.path.join(DISTRO_BASE, "installed-rootfs", "debian")):
        if os.path.isdir(os.path.join(c, "usr", "bin")):
            return c
    try:
        for d1 in sorted(os.listdir(DISTRO_BASE)):
            p1 = os.path.join(DISTRO_BASE, d1)
            if not os.path.isdir(p1) or os.path.islink(p1):
                continue
            if os.path.isdir(os.path.join(p1, "usr", "bin")) and "debian" in d1:
                return p1
            for d2 in sorted(os.listdir(p1)):
                p2 = os.path.join(p1, d2)
                if os.path.isdir(p2) and not os.path.islink(p2) and "debian" in d2:
                    if os.path.isdir(os.path.join(p2, "usr", "bin")):
                        return p2
                    for d3 in sorted(os.listdir(p2)):
                        p3 = os.path.join(p2, d3)
                        if os.path.isdir(os.path.join(p3, "usr", "bin")) and not os.path.islink(p3):
                            return p3
    except OSError:
        pass
    return None


ROOTFS = os.environ.get("PANEL_ROOTFS") or find_rootfs() or os.path.join(DISTRO_BASE, "installed-rootfs", "debian")
SRV = os.path.join(ROOTFS, "srv/bds")


def resolve_paths():
    global ROOTFS, SRV
    if not os.environ.get("PANEL_ROOTFS"):
        r = find_rootfs()
        if r:
            ROOTFS = r
    SRV = os.path.join(ROOTFS, "srv/bds")
CACHE = os.path.join(HOME, "cache")
TOKEN = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("PANEL_TOKEN", "")
BDS_URL = "https://www.minecraft.net/bedrockdedicatedserver/bin-linux/bedrock-server-%s.zip"
PLAYIT_URL = "https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-linux-aarch64"
UA = "Mozilla/5.0 (X11; Linux aarch64) BedrockPhoneHost"
ANSI = re.compile(r"\x1b\[[;?0-9]*[A-Za-z]")
RE_JOIN = re.compile(r"Player connected: (.+?), xuid")
RE_LEFT = re.compile(r"Player disconnected: (.+?), xuid")
RE_CLAIM = re.compile(r"https://playit\.gg/claim/\S+")
RE_ADDR = re.compile(r"([A-Za-z0-9.-]+\.(?:ply\.gg|joinmc\.link)):(\d+)")


class S:
    lock = threading.RLock()
    status = "stopped"      # stopped | installing | starting | running | stopping
    progress = ""
    version = ""
    started = 0.0
    players = set()
    server = None
    tunnel = None
    claim = ""
    addr = ""
    log_n = 0
    logs = deque(maxlen=1500)
    busy = False
    storage_cache = (0.0, {})


def log(line):
    with S.lock:
        S.log_n += 1
        S.logs.append((S.log_n, line))


# ---------------------------------------------------------------- settings
SETTINGS = os.path.join(HOME, "settings.json")


def load_settings():
    try:
        with open(SETTINGS) as f:
            d = json.load(f)
    except Exception:
        d = {}
    out = {"props": {}, "tunnel": True, "secret": "", "manual": "", "world_limit_mb": 0, "version": ""}
    out.update(d)
    out["props"] = dict(out.get("props") or {})
    return out


def save_settings(d):
    os.makedirs(HOME, exist_ok=True)
    tmp = SETTINGS + ".tmp"
    with open(tmp, "w") as f:
        json.dump(d, f)
    os.replace(tmp, SETTINGS)


def clean_overrides(d):
    return {k: str(v) for k, v in d.items() if str(v).strip() != "" or k == "level-seed"}


def props_path():
    return os.path.join(SRV, "server.properties")


def read_props():
    m = {}
    try:
        with open(props_path(), encoding="utf-8", errors="replace") as f:
            for l in f:
                l = l.rstrip("\n")
                if l.startswith("#") or "=" not in l:
                    continue
                k, v = l.split("=", 1)
                m[k.strip()] = v.strip()
    except OSError:
        pass
    return m


def write_props(updates):
    try:
        with open(props_path(), encoding="utf-8", errors="replace") as f:
            lines = f.read().split("\n")
        if lines and lines[-1] == "":
            lines.pop()
    except OSError:
        lines = []
    done = set()
    for i, l in enumerate(lines):
        if l.startswith("#") or "=" not in l:
            continue
        k = l.split("=", 1)[0].strip()
        if k in updates:
            lines[i] = "%s=%s" % (k, updates[k])
            done.add(k)
    for k, v in updates.items():
        if k not in done:
            lines.append("%s=%s" % (k, v))
    os.makedirs(SRV, exist_ok=True)
    with open(props_path(), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def effective_props():
    p = read_props()
    p.update(clean_overrides(load_settings()["props"]))
    return p


def level_name():
    return effective_props().get("level-name") or "Bedrock level"


def world_dir():
    return os.path.join(SRV, "worlds", level_name())


# ---------------------------------------------------------------- helpers
def dir_size(p):
    t = 0
    for r, _ds, fs in os.walk(p):
        for f in fs:
            fp = os.path.join(r, f)
            try:
                if not os.path.islink(fp):
                    t += os.path.getsize(fp)
            except OSError:
                pass
    return t


def local_ips():
    v4 = v6 = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); v4 = s.getsockname()[0]; s.close()
    except Exception:
        pass
    try:
        s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        s.connect(("2001:4860:4860::8888", 80)); v6 = s.getsockname()[0]; s.close()
    except Exception:
        pass
    if v4 and v4.startswith("127."):
        v4 = None
    return v4, v6


def safe_unzip(zpath, out):
    os.makedirs(out, exist_ok=True)
    root = os.path.realpath(out)
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            name = info.filename.replace("\\", "/")
            dest = os.path.realpath(os.path.join(out, name))
            if not (dest == root or dest.startswith(root + os.sep)):
                continue
            if info.is_dir() or name.endswith("/"):
                os.makedirs(dest, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(info) as s, open(dest, "wb") as o:
                shutil.copyfileobj(s, o)


def download(url, dest, what):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    part = dest + ".part"
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as r, open(part, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = last = 0
        while True:
            b = r.read(65536)
            if not b:
                break
            f.write(b); done += len(b)
            if done - last > 524288:
                last = done
                S.progress = ("%s %d%% (%d MB)" % (what, done * 100 // total, done >> 20)) if total else ("%s %d MB" % (what, done >> 20))
    os.replace(part, dest)
    S.progress = ""


def run_lines(cmd, prefix=""):
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace", bufsize=1)
    for line in p.stdout:
        line = ANSI.sub("", line.rstrip())
        if line:
            log(prefix + line)
    return p.wait()


os.environ["PROOT_NO_SECCOMP"] = "1"


def distro_cmd(inner):
    return ["proot-distro", "login", "debian", "--", "bash", "-c", inner]


MARKER = os.path.join(HOME, "runtime.ok")


def runtime_ready():
    return os.path.exists(MARKER)


def installed_version():
    try:
        with open(os.path.join(SRV, "installed_version.txt")) as f:
            return f.read().strip()
    except OSError:
        return ""


# ---------------------------------------------------------------- setup / install
def setup_runtime():
    log("== Setting up Linux (one time, needs internet) ==")
    os.makedirs(HOME, exist_ok=True)
    if FAKE:
        os.makedirs(SRV, exist_ok=True)
        open(MARKER, "w").write("ok")
        return
    resolve_paths()
    if not os.path.isdir(os.path.join(ROOTFS, "usr")):
        # Debian may already be installed (for example from a manual test) even if we could not see its folder.
        if run_lines(["proot-distro", "login", "debian", "--", "true"]) != 0:
            log("Installing Debian (about 50 MB)...")
            rc = run_lines(["proot-distro", "install", "debian"])
            if rc != 0:
                raise RuntimeError("Installing Debian failed (code %s)." % rc)
        resolve_paths()
        if not os.path.isdir(os.path.join(ROOTFS, "usr")):
            try:
                seen = ", ".join(sorted(os.listdir(DISTRO_BASE)))
            except OSError:
                seen = "(folder missing)"
            raise RuntimeError("Debian is installed but I could not find its folder. Looked in %s. Found: %s" % (DISTRO_BASE, seen))
        log("Found Debian at %s" % ROOTFS)
    os.makedirs(SRV, exist_ok=True)
    os.makedirs(os.path.join(ROOTFS, "usr/local/bin"), exist_ok=True)
    log("Installing box64 and libraries (a few minutes)...")
    # dpkg itself segfaults under proot on this phone, so never run it for installs:
    # only apt-get update / apt-get download, then unpack the .deb files with dpkg-deb -x.
    script = (
        "export DEBIAN_FRONTEND=noninteractive; "
        "N=$(dpkg --print-architecture); printf '%s\\namd64\\n' \"$N\" > /var/lib/dpkg/arch; "
        "apt-get update && mkdir -p /tmp/debs && cd /tmp/debs && rm -f *.deb && "
        "L=$(apt-cache depends --recurse --no-recommends --no-suggests --no-conflicts --no-breaks --no-replaces --no-enhances "
        "libc6:amd64 libstdc++6:amd64 libgcc-s1:amd64 libcurl4t64:amd64 2>/dev/null | grep '^[a-z0-9]' | grep ':amd64' | sort -u) && "
        "echo \"Downloading: $L box64\" && apt-get download $L box64 && "
        "for f in /tmp/debs/*.deb; do echo \"Unpacking $f\"; dpkg-deb -x \"$f\" / || exit 1; done; "
        "ldconfig 2>/dev/null; rm -rf /tmp/debs; "
        "box64 --version"
    )
    rc = run_lines(distro_cmd(script))
    if rc != 0:
        raise RuntimeError("Installing box64 failed (code %s). See the lines above." % rc)
    log("Downloading Playit.gg agent...")
    pl = os.path.join(ROOTFS, "usr/local/bin/playit")
    download(PLAYIT_URL, pl, "playit")
    os.chmod(pl, 0o755)
    open(MARKER, "w").write("ok")
    log("== Linux ready ==")


FAKE_BDS = r'''
import sys, time, threading
def out(s): print(s, flush=True)
out("[INFO] Starting Server"); time.sleep(1); out("[INFO] Server started.")
def later():
    time.sleep(3); out("[INFO] Player connected: Steve, xuid: 111"); time.sleep(3); out("[INFO] Player connected: Alex, xuid: 222")
threading.Thread(target=later, daemon=True).start()
for line in sys.stdin:
    c = line.strip(); out("[INFO] cmd: " + c)
    if c == "stop": out("[INFO] Quit correctly"); break
'''


def install_version(ver):
    log("== Installing Bedrock server %s ==" % ver)
    os.makedirs(SRV, exist_ok=True)
    first = not os.path.exists(os.path.join(SRV, "installed_version.txt"))
    if FAKE:
        if not os.path.exists(props_path()):
            write_props({"server-name": "Dedicated Server", "gamemode": "survival", "max-players": "10", "level-name": "Bedrock level"})
        open(os.path.join(SRV, "bedrock_server.py"), "w").write(FAKE_BDS)
    else:
        zpath = os.path.join(CACHE, "bds.zip")
        try:
            download(BDS_URL % ver, zpath, "bedrock " + ver)
        except Exception as e:
            raise RuntimeError("Could not download version %s (%s). Check the exact version, e.g. 1.21.50.07" % (ver, e))
        managed = {a["dir"] for a in addons_list()}
        for sub in ("behavior_packs", "resource_packs"):
            d = os.path.join(SRV, sub)
            if os.path.isdir(d):
                for n in os.listdir(d):
                    if sub + "/" + n not in managed:
                        shutil.rmtree(os.path.join(d, n), ignore_errors=True)
        keep = {"server.properties", "allowlist.json", "permissions.json"}
        root = os.path.realpath(SRV)
        with zipfile.ZipFile(zpath) as z:
            for info in z.infolist():
                name = info.filename
                if info.is_dir() or name.endswith("/"):
                    continue
                dest = os.path.realpath(os.path.join(SRV, name))
                if not dest.startswith(root + os.sep):
                    continue
                if name in keep and os.path.exists(dest):
                    continue
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with z.open(info) as s, open(dest, "wb") as o:
                    shutil.copyfileobj(s, o)
        os.remove(zpath)
        bs = os.path.join(SRV, "bedrock_server")
        if os.path.exists(bs):
            os.chmod(bs, 0o755)
    if first:
        write_props({"view-distance": "6", "tick-distance": "4"})
    with open(os.path.join(SRV, "installed_version.txt"), "w") as f:
        f.write(ver)
    log("== Installed %s ==" % ver)


# ---------------------------------------------------------------- run / stop
def send_cmd(c):
    p = S.server
    if p and c.strip():
        try:
            p.stdin.write(c.strip() + "\n"); p.stdin.flush()
        except Exception:
            pass


def stop_server():
    p = S.server
    if not p:
        return False
    S.status = "stopping"
    send_cmd("stop")

    def killer():
        try:
            p.wait(30)
        except subprocess.TimeoutExpired:
            p.kill()
    threading.Thread(target=killer, daemon=True).start()
    return True


def start_tunnel(st):
    pl = os.path.join(ROOTFS, "usr/local/bin/playit")
    if FAKE or not st.get("tunnel") or not os.path.exists(pl):
        return
    secret = (st.get("secret") or "").strip()
    inner = "exec playit" + (" --secret " + shlex.quote(secret) if secret else "")

    def run():
        try:
            p = subprocess.Popen(distro_cmd(inner), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, errors="replace", bufsize=1)
            S.tunnel = p
            for raw in p.stdout:
                line = ANSI.sub("", raw.rstrip())
                if line.strip():
                    log("[playit] " + line)
                m = RE_CLAIM.search(line)
                if m:
                    S.claim = m.group(0)
                m = RE_ADDR.search(line)
                if m:
                    S.addr = "%s:%s" % (m.group(1), m.group(2)); S.claim = ""
        except Exception as e:
            log("[playit] error: %s" % e)
    threading.Thread(target=run, daemon=True).start()


def monitor_world(limit_mb):
    if limit_mb <= 0:
        return
    warned = False
    while S.status in ("starting", "running"):
        for _ in range(60):
            if S.status not in ("starting", "running"):
                return
            time.sleep(1)
        mb = dir_size(world_dir()) >> 20
        if mb >= limit_mb:
            log("World is %d MB, over your %d MB limit. Stopping server." % (mb, limit_mb))
            stop_server()
            return
        if not warned and mb >= limit_mb * 9 // 10:
            warned = True
            log("Warning: world is %d MB, 90%% of your %d MB limit." % (mb, limit_mb))


def run_server(version):
    with S.lock:
        if S.busy:
            return
        S.busy = True
    try:
        resolve_paths()
        S.players = set(); S.claim = ""; S.addr = ""
        S.status = "installing"
        try:
            if not runtime_ready():
                setup_runtime()
            st = load_settings()
            ver = version or st.get("version") or installed_version()
            if not ver:
                raise RuntimeError("Enter a Minecraft Bedrock version first.")
            if installed_version() != ver:
                install_version(ver)
            st["version"] = ver
            save_settings(st)
            S.version = ver
            ov = clean_overrides(st["props"])
            if ov:
                write_props(ov)
        except Exception as e:
            log("ERROR: %s" % e)
            S.progress = ""; S.status = "stopped"
            return
        S.status = "starting"; S.started = time.time()
        try:
            subprocess.run(["termux-wake-lock"], timeout=5)
        except Exception:
            pass
        start_tunnel(st)
        threading.Thread(target=monitor_world, args=(int(st.get("world_limit_mb") or 0),), daemon=True).start()
        try:
            if FAKE:
                p = subprocess.Popen([sys.executable, "bedrock_server.py"], cwd=SRV, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True, errors="replace", bufsize=1)
            else:
                p = subprocess.Popen(distro_cmd("cd /srv/bds && exec env BOX64_LOG=0 BOX64_LD_LIBRARY_PATH=. box64 ./bedrock_server"),
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                     text=True, errors="replace", bufsize=1)
            S.server = p
            for raw in p.stdout:
                line = ANSI.sub("", raw.rstrip())
                log(line)
                if "Server started." in line:
                    S.status = "running"
                m = RE_JOIN.search(line)
                if m:
                    S.players = S.players | {m.group(1)}
                m = RE_LEFT.search(line)
                if m:
                    S.players = S.players - {m.group(1)}
            log("== Server exited (code %s) ==" % p.wait())
        except Exception as e:
            log("ERROR: %s" % e)
        finally:
            S.server = None
            if S.tunnel:
                try:
                    S.tunnel.terminate()
                except Exception:
                    pass
                S.tunnel = None
            S.players = set(); S.addr = ""; S.claim = ""; S.status = "stopped"
            try:
                subprocess.run(["termux-wake-unlock"], timeout=5)
            except Exception:
                pass
    finally:
        S.busy = False


# ---------------------------------------------------------------- addons
def addons_db():
    return os.path.join(SRV, "addons.json")


def addons_list():
    try:
        with open(addons_db()) as f:
            return json.load(f)
    except Exception:
        return []


def addons_save(l):
    os.makedirs(SRV, exist_ok=True)
    with open(addons_db(), "w") as f:
        json.dump(l, f)


def lenient_json(path):
    with open(path, encoding="utf-8-sig", errors="replace") as f:
        text = f.read()
    try:
        return json.loads(text)
    except ValueError:
        pass
    t = re.sub(r'("(?:\\.|[^"\\])*")|/\*.*?\*/|//[^\n]*', lambda m: m.group(1) or "", text, flags=re.S)
    t = re.sub(r",\s*([}\]])", r"\1", t)
    return json.loads(t)


def parse_ver(v):
    if isinstance(v, list):
        return [int(x) for x in v]
    if isinstance(v, str):
        r = [int(x) for x in re.findall(r"\d+", v)]
        return r or [1, 0, 0]
    return [1, 0, 0]


def world_pack_file(typ):
    return os.path.join(world_dir(), "world_resource_packs.json" if typ == "resource" else "world_behavior_packs.json")


def edit_world(typ, uuid, version):
    f = world_pack_file(typ)
    os.makedirs(os.path.dirname(f), exist_ok=True)
    try:
        with open(f) as fh:
            arr = json.load(fh)
    except Exception:
        arr = []
    arr = [o for o in arr if o.get("pack_id") != uuid]
    if version is not None:
        arr.append({"pack_id": uuid, "version": version})
    with open(f, "w") as fh:
        json.dump(arr, fh)


def install_pack(root, acc):
    j = lenient_json(os.path.join(root, "manifest.json"))
    h = j["header"]
    uuid = h["uuid"]
    ver = parse_ver(h.get("version"))
    typ = "behavior"
    for m in j.get("modules") or []:
        if m.get("type") == "resources":
            typ = "resource"
    name = h.get("name") or os.path.basename(root)
    if name.startswith("pack."):
        name = os.path.basename(root)
    dname = re.sub(r"[^A-Za-z0-9_-]", "_", name)[:40] + "_" + uuid[:6]
    sub = "resource_packs" if typ == "resource" else "behavior_packs"
    target = os.path.join(SRV, sub, dname)
    shutil.rmtree(target, ignore_errors=True)
    shutil.copytree(root, target)
    edit_world(typ, uuid, ver)
    acc.append({"name": name, "type": typ, "uuid": uuid, "version": ver, "dir": sub + "/" + dname})
    shutil.rmtree(root, ignore_errors=True)


def scan(d, acc):
    archives = []
    for r, _ds, fs in os.walk(d):
        for f in fs:
            if f.lower().rsplit(".", 1)[-1] in ("mcpack", "mcaddon", "zip") and "." in f:
                archives.append(os.path.join(r, f))
    for a in archives:
        out = os.path.splitext(a)[0] + "_x"
        try:
            safe_unzip(a, out)
        except zipfile.BadZipFile:
            continue
        os.remove(a)
        scan(out, acc)
    manifests = []
    for r, _ds, fs in os.walk(d):
        if "manifest.json" in fs:
            manifests.append(r)
    for r in manifests:
        if os.path.exists(os.path.join(r, "manifest.json")):
            install_pack(r, acc)


def import_addon(path):
    work = tempfile.mkdtemp(dir=CACHE)
    try:
        x = os.path.join(work, "x")
        safe_unzip(path, x)
        acc = []
        scan(x, acc)
        if not acc:
            return "No pack (manifest.json) found in that file."
        ids = {a["uuid"] for a in acc}
        addons_save([a for a in addons_list() if a["uuid"] not in ids] + acc)
        return "Installed: " + ", ".join("%s (%s)" % (a["name"], a["type"]) for a in acc) + ". Restart the server to apply."
    except Exception as e:
        return "Import failed: %s" % e
    finally:
        shutil.rmtree(work, ignore_errors=True)


def remove_addon(uuid):
    for a in addons_list():
        if a["uuid"] == uuid:
            shutil.rmtree(os.path.join(SRV, a["dir"]), ignore_errors=True)
            edit_world(a["type"], uuid, None)
    addons_save([a for a in addons_list() if a["uuid"] != uuid])


# ---------------------------------------------------------------- worlds
def import_world(path):
    work = tempfile.mkdtemp(dir=CACHE)
    try:
        x = os.path.join(work, "x")
        safe_unzip(path, x)
        cands = []
        for r, _ds, fs in os.walk(x):
            if "level.dat" in fs:
                cands.append(r)
        if not cands:
            return "That file has no world in it (level.dat not found)."
        root = min(cands, key=len)
        name = "Imported World"
        ln = os.path.join(root, "levelname.txt")
        if os.path.exists(ln):
            with open(ln, encoding="utf-8", errors="replace") as f:
                name = f.read().strip() or name
        folder = re.sub(r"[^A-Za-z0-9 _-]", "_", name)[:40] or "world"
        target = os.path.join(SRV, "worlds", folder)
        note = ""
        if os.path.exists(target):
            bk = os.path.join(SRV, "world_backups", "%s_%d" % (folder, int(time.time())))
            os.makedirs(os.path.dirname(bk), exist_ok=True)
            shutil.move(target, bk)
            note = " The old world with that name was backed up."
        os.makedirs(os.path.dirname(target), exist_ok=True)
        shutil.copytree(root, target)
        st = load_settings()
        st["props"]["level-name"] = folder
        save_settings(st)
        write_props({"level-name": folder})
        return 'Imported "%s" and made it the active world.%s Press Start to play it.' % (name, note)
    except Exception as e:
        return "Import failed: %s" % e
    finally:
        shutil.rmtree(work, ignore_errors=True)


def export_world():
    d = world_dir()
    if not os.path.isdir(d):
        return None
    out = os.path.join(CACHE, "export.mcworld")
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for r, _ds, fs in os.walk(d):
            for f in fs:
                fp = os.path.join(r, f)
                z.write(fp, os.path.relpath(fp, d).replace(os.sep, "/"))
    return out


# ---------------------------------------------------------------- HTTP API
def storage():
    now = time.time()
    if now - S.storage_cache[0] < 60 and S.storage_cache[1]:
        data = dict(S.storage_cache[1])
    else:
        data = {"world": dir_size(world_dir()), "server": dir_size(SRV), "runtime": dir_size(ROOTFS) if os.path.isdir(ROOTFS) else 0}
        S.storage_cache = (now, data)
    os.makedirs(HOME, exist_ok=True)
    data["free"] = shutil.disk_usage(HOME).free
    return data


def state():
    st = load_settings()
    v4, v6 = local_ips()
    eff = effective_props()
    return {
        "status": S.status, "progress": S.progress, "version": S.version or st.get("version", ""),
        "installed_version": installed_version(), "runtime_ready": runtime_ready(),
        "players": sorted(S.players), "max_players": eff.get("max-players", "10"),
        "started": S.started, "playit": {"address": S.addr, "claim": S.claim},
        "manual": st.get("manual", ""), "tunnel": bool(st.get("tunnel")),
        "ips": {"v4": v4, "v6": v6}, "level_name": level_name(),
    }


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def send_json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def body_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        try:
            return json.loads(self.rfile.read(n).decode("utf-8"))
        except ValueError:
            return {}

    def body_file(self):
        n = int(self.headers.get("Content-Length") or 0)
        os.makedirs(CACHE, exist_ok=True)
        path = os.path.join(CACHE, "upload_%d.bin" % int(time.time() * 1000))
        with open(path, "wb") as f:
            left = n
            while left > 0:
                b = self.rfile.read(min(65536, left))
                if not b:
                    break
                f.write(b); left -= len(b)
        return path

    def do_GET(self):
        self.route("GET")

    def do_POST(self):
        self.route("POST")

    def route(self, method):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        path = u.path
        if TOKEN and self.headers.get("X-Token") != TOKEN:
            self.close_connection = True
            return self.send_json(401, {"error": "bad token"})
        try:
            if method == "GET":
                if path == "/ping":
                    return self.send_json(200, {"ok": True})
                if path == "/state":
                    return self.send_json(200, state())
                if path == "/logs":
                    since = int(q.get("since", ["0"])[0])
                    with S.lock:
                        if since > S.log_n:
                            since = 0
                        lines = [l for i, l in S.logs if i > since]
                        nxt = S.log_n
                    return self.send_json(200, {"lines": lines, "next": nxt})
                if path == "/settings":
                    st = load_settings()
                    return self.send_json(200, {"props": effective_props(), "tunnel": bool(st["tunnel"]), "secret": st["secret"],
                                                "manual": st["manual"], "world_limit_mb": int(st["world_limit_mb"] or 0)})
                if path == "/storage":
                    return self.send_json(200, storage())
                if path == "/addons":
                    return self.send_json(200, {"addons": addons_list()})
                if path == "/world/export":
                    out = export_world()
                    if not out:
                        return self.send_json(404, {"message": "No world yet. Start the server once so it creates one."})
                    size = os.path.getsize(out)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/octet-stream")
                    self.send_header("Content-Length", str(size))
                    self.end_headers()
                    with open(out, "rb") as f:
                        shutil.copyfileobj(f, self.wfile)
                    os.remove(out)
                    return
            else:
                if path == "/start":
                    d = self.body_json()
                    if S.busy or S.status != "stopped":
                        return self.send_json(200, {"ok": False, "message": "Already running"})
                    threading.Thread(target=run_server, args=(str(d.get("version", "")).strip(),), daemon=True).start()
                    return self.send_json(200, {"ok": True})
                if path == "/stop":
                    self.body_json()
                    return self.send_json(200, {"ok": stop_server()})
                if path == "/cmd":
                    send_cmd(str(self.body_json().get("cmd", "")))
                    return self.send_json(200, {"ok": True})
                if path == "/settings":
                    d = self.body_json()
                    st = load_settings()
                    if isinstance(d.get("props"), dict):
                        st["props"].update({str(k): str(v) for k, v in d["props"].items()})
                    for k in ("tunnel", "secret", "manual", "world_limit_mb"):
                        if k in d:
                            st[k] = d[k]
                    save_settings(st)
                    return self.send_json(200, {"ok": True})
                if path in ("/addons/import", "/world/import"):
                    f = self.body_file()
                    try:
                        if S.status != "stopped":
                            return self.send_json(200, {"message": "Stop the server first."})
                        msg = import_addon(f) if path == "/addons/import" else import_world(f)
                        S.storage_cache = (0.0, {})
                        return self.send_json(200, {"message": msg})
                    finally:
                        try:
                            os.remove(f)
                        except OSError:
                            pass
                if path == "/addons/remove":
                    if S.status != "stopped":
                        return self.send_json(200, {"message": "Stop the server first."})
                    remove_addon(str(self.body_json().get("uuid", "")))
                    return self.send_json(200, {"ok": True})
            self.send_json(404, {"error": "not found"})
        except Exception as e:
            try:
                self.send_json(500, {"error": str(e), "message": "Error: %s" % e})
            except Exception:
                pass


def main():
    os.makedirs(HOME, exist_ok=True)
    os.makedirs(CACHE, exist_ok=True)
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    srv.daemon_threads = True

    def term(*_a):
        stop_server()
        t0 = time.time()
        while S.server and time.time() - t0 < 35:
            time.sleep(0.5)
        os._exit(0)
    signal.signal(signal.SIGTERM, term)
    signal.signal(signal.SIGINT, term)
    log("Panel ready.")
    srv.serve_forever()


if __name__ == "__main__":
    main()
