package com.phonehost.bedrock

import java.io.File

class Props(p: Paths) {
    private val f = File(p.serverDir, "server.properties")

    fun read(): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        if (f.exists()) f.readLines().forEach {
            if (!it.startsWith("#") && it.contains("=")) m[it.substringBefore("=").trim()] = it.substringAfter("=").trim()
        }
        return m
    }

    fun write(updates: Map<String, String>) {
        val lines = if (f.exists()) f.readLines().toMutableList() else mutableListOf()
        val done = mutableSetOf<String>()
        for (i in lines.indices) {
            val l = lines[i]
            if (l.startsWith("#") || !l.contains("=")) continue
            val k = l.substringBefore("=").trim()
            if (updates.containsKey(k)) { lines[i] = "$k=${updates[k]}"; done += k }
        }
        updates.forEach { (k, v) -> if (k !in done) lines += "$k=$v" }
        f.parentFile?.mkdirs()
        f.writeText(lines.joinToString("\n") + "\n")
    }
}
