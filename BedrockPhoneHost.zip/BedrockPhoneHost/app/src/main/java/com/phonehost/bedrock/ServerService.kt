package com.phonehost.bedrock

import android.app.*
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.*
import java.util.concurrent.TimeUnit

class ServerService : Service() {
    companion object {
        const val START = "start"; const val STOP = "stop"; const val CMD = "cmd"
        private const val CH = "server"
        private val ansi = Regex("\u001B\\[[;?0-9]*[A-Za-z]")
        private val joined = Regex("Player connected: (.+?), xuid")
        private val left = Regex("Player disconnected: (.+?), xuid")
        private val claim = Regex("https://playit\\.gg/claim/\\S+")
        private val addr = Regex("([A-Za-z0-9.-]+\\.(?:ply\\.gg|joinmc\\.link)):(\\d+)")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var server: Process? = null
    private var tunnel: Process? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var busy = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        when (i?.action) {
            START -> {
                startForeground(1, notif("Starting..."))
                val v = i.getStringExtra("version") ?: ""
                if (!busy) { busy = true; scope.launch { try { runServer(v) } finally { busy = false } } }
            }
            STOP -> scope.launch { stopServer() }
            CMD -> sendCommand(i.getStringExtra("cmd") ?: "")
        }
        return START_NOT_STICKY
    }

    private fun notif(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Server", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, ServerService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Bedrock server").setContentText(text)
            .setContentIntent(open).setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stop).build()
    }

    private fun updateNotif(text: String) =
        getSystemService(NotificationManager::class.java).notify(1, notif(text))

    private suspend fun runServer(version: String) {
        val st = ServerState
        val p = Paths(this)
        val inst = Installer(p, { st.log(it) }, { st.progress.value = it })
        st.players.value = emptySet(); st.claimUrl.value = ""
        try {
            st.status.value = Status.SETTING_UP
            updateNotif("Installing...")
            if (!inst.runtimeReady()) inst.setupRuntime()
            val v = version.ifBlank { inst.installedVersion() }
            if (v.isBlank()) throw IllegalStateException("Enter a Minecraft Bedrock version first.")
            if (inst.installedVersion() != v) inst.installBedrock(v)
            st.version.value = v
            Prefs(this).propOverrides().let { if (it.isNotEmpty()) Props(p).write(it) }
        } catch (e: Exception) {
            st.log("ERROR: ${e.message}")
            st.progress.value = ""; st.status.value = Status.STOPPED
            stopForeground(true); stopSelf(); return
        }

        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "bedrock:server").also { it.acquire() }
        @Suppress("DEPRECATION")
        wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "bedrock:wifi").also { it.acquire() }

        startTunnel(p)
        val monitor = scope.launch { monitorWorld(p) }
        st.status.value = Status.STARTING
        st.startedAt.value = System.currentTimeMillis()
        updateNotif("Starting server...")
        val watcher = scope.launch { st.players.collect { if (st.status.value == Status.RUNNING) updateNotif("${it.size} player(s) online") } }

        try {
            val pr = p.process("exec box64 ./bedrock_server").start()
            server = pr
            pr.inputStream.bufferedReader().forEachLine { raw ->
                val line = ansi.replace(raw, "")
                st.log(line)
                if (line.contains("Server started.")) { st.status.value = Status.RUNNING; updateNotif("Running") }
                joined.find(line)?.let { st.players.value = st.players.value + it.groupValues[1] }
                left.find(line)?.let { st.players.value = st.players.value - it.groupValues[1] }
            }
            val code = pr.waitFor()
            st.log("== Server exited (code $code) ==")
        } catch (e: Exception) {
            st.log("ERROR: ${e.message}")
        }
        watcher.cancel(); monitor.cancel()
        tunnel?.destroy(); tunnel = null; server = null
        wake?.let { if (it.isHeld) it.release() }; wifi?.let { if (it.isHeld) it.release() }
        st.players.value = emptySet(); st.playitAddress.value = ""
        st.status.value = Status.STOPPED
        stopForeground(true); stopSelf()
    }

    private suspend fun monitorWorld(p: Paths) {
        val limit = Prefs(this).worldLimitMb
        if (limit <= 0) return
        var warned = false
        while (true) {
            delay(60_000)
            val mb = Worlds(p).sizeBytes() / 1048576
            if (mb >= limit) {
                ServerState.log("World is $mb MB, over your $limit MB limit. Stopping server.")
                stopServer(); return
            }
            if (!warned && mb >= limit * 9 / 10) { warned = true; ServerState.log("Warning: world is $mb MB, 90% of your $limit MB limit.") }
        }
    }

    private fun shq(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun startTunnel(p: Paths) {
        val prefs = Prefs(this)
        if (!prefs.useTunnel || !p.playit.exists()) return
        val cmd = if (prefs.playitSecret.isBlank()) "exec playit" else "exec playit --secret ${shq(prefs.playitSecret)}"
        scope.launch {
            try {
                val pr = p.process(cmd, "/root").start()
                tunnel = pr
                pr.inputStream.bufferedReader().forEachLine { raw ->
                    val line = ansi.replace(raw, "")
                    if (line.isNotBlank()) ServerState.log("[playit] $line")
                    claim.find(line)?.let { ServerState.claimUrl.value = it.value }
                    addr.find(line)?.let { ServerState.playitAddress.value = it.groupValues[1] + ":" + it.groupValues[2]; ServerState.claimUrl.value = "" }
                }
            } catch (e: Exception) { ServerState.log("[playit] error: ${e.message}") }
        }
    }

    private fun sendCommand(c: String) {
        if (c.isBlank()) return
        try { server?.outputStream?.let { it.write((c.trim() + "\n").toByteArray()); it.flush() } } catch (_: Exception) {}
    }

    private suspend fun stopServer() {
        val pr = server ?: run { stopSelf(); return }
        ServerState.status.value = Status.STOPPING
        sendCommand("stop")
        if (!withContext(Dispatchers.IO) { pr.waitFor(25, TimeUnit.SECONDS) }) pr.destroyForcibly()
    }

    override fun onDestroy() {
        tunnel?.destroy(); server?.destroy(); scope.cancel()
        wake?.let { if (it.isHeld) it.release() }; wifi?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
