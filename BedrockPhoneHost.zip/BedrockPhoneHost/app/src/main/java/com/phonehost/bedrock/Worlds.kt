package com.phonehost.bedrock

import android.content.Context
import android.net.Uri
import android.os.StatFs
import java.io.File
import java.nio.file.FileVisitResult
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.SimpleFileVisitor
import java.nio.file.attribute.BasicFileAttributes
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class Storage(val world: Long, val app: Long, val free: Long)

fun fmtSize(b: Long): String = when {
    b >= 1073741824L -> "%.2f GB".format(b / 1073741824.0)
    b >= 1048576L -> "%d MB".format(b / 1048576)
    else -> "%d KB".format(b / 1024)
}

/** Total size of regular files, without following symlinks. */
fun dirSize(f: File): Long {
    if (!f.exists()) return 0
    var total = 0L
    Files.walkFileTree(f.toPath(), object : SimpleFileVisitor<Path>() {
        override fun visitFile(file: Path, attrs: BasicFileAttributes): FileVisitResult {
            if (attrs.isRegularFile) total += attrs.size(); return FileVisitResult.CONTINUE
        }
        override fun visitFileFailed(file: Path, exc: java.io.IOException) = FileVisitResult.CONTINUE
    })
    return total
}

class Worlds(private val p: Paths) {
    fun levelName() = Props(p).read()["level-name"] ?: "Bedrock level"
    private fun worldDir() = File(p.serverDir, "worlds/" + levelName())
    fun sizeBytes() = dirSize(worldDir())
    fun storage() = Storage(sizeBytes(), dirSize(p.base), StatFs(p.base.path).availableBytes)

    fun importWorld(ctx: Context, uri: Uri): String {
        val work = File(ctx.cacheDir, "world_" + System.nanoTime()).apply { mkdirs() }
        return try {
            val src = File(work, "src.zip")
            ctx.contentResolver.openInputStream(uri)!!.use { i -> src.outputStream().use { i.copyTo(it) } }
            val x = File(work, "x"); Net.unzip(src, x)
            val lvl = x.walkTopDown().filter { it.isFile && it.name == "level.dat" }.minByOrNull { it.path.length }
                ?: return "That file has no world in it (level.dat not found)."
            val root = lvl.parentFile!!
            val name = File(root, "levelname.txt").takeIf { it.exists() }?.readText()?.trim().orEmpty().ifBlank { "Imported World" }
            val folder = name.replace(Regex("[^A-Za-z0-9 _-]"), "_").take(40).ifBlank { "world" }
            val target = File(p.serverDir, "worlds/$folder")
            var note = ""
            if (target.exists()) {
                val bk = File(p.serverDir, "world_backups/${folder}_" + System.currentTimeMillis())
                bk.parentFile?.mkdirs()
                if (!target.renameTo(bk)) { target.copyRecursively(bk, true); target.deleteRecursively() }
                note = " The old world with that name was backed up."
            }
            target.parentFile?.mkdirs()
            root.copyRecursively(target, true)
            Props(p).write(mapOf("level-name" to folder))
            "Imported \"$name\" and made it the active world.$note Press Start to play it."
        } catch (e: Exception) { "Import failed: ${e.message}" } finally { work.deleteRecursively() }
    }

    fun exportWorld(ctx: Context, uri: Uri): String {
        val dir = worldDir()
        if (!dir.exists()) return "No world yet. Start the server once so it creates one."
        return try {
            ZipOutputStream(ctx.contentResolver.openOutputStream(uri)!!.buffered()).use { z ->
                dir.walkTopDown().filter { it.isFile }.forEach { f ->
                    z.putNextEntry(ZipEntry(f.relativeTo(dir).path.replace('\\', '/')))
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
            "Exported \"${levelName()}\" (${fmtSize(dirSize(dir))} of world data)."
        } catch (e: Exception) { "Export failed: ${e.message}" }
    }
}
