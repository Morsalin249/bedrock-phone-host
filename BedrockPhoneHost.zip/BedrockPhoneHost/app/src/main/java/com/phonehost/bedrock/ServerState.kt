package com.phonehost.bedrock

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

enum class Status { STOPPED, SETTING_UP, STARTING, RUNNING, STOPPING }

object ServerState {
    val status = MutableStateFlow(Status.STOPPED)
    val logs = MutableStateFlow<List<String>>(emptyList())
    val players = MutableStateFlow<Set<String>>(emptySet())
    val progress = MutableStateFlow("")
    val startedAt = MutableStateFlow(0L)
    val version = MutableStateFlow("")
    val playitAddress = MutableStateFlow("")
    val claimUrl = MutableStateFlow("")

    fun log(line: String) { logs.update { (it + line).takeLast(600) } }
}
