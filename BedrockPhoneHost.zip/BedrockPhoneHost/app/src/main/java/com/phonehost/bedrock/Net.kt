package com.phonehost.bedrock

import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object Net {
    fun download(url: String, dest: File, onProgress: (Long, Long) -> Unit = { _, _ -> }, headers: Map<String, String> = emptyMap()) {
        dest.parentFile?.mkdirs()
        val part = File(dest.path + ".part")
        var u = url
        var hops = 0
        var conn: HttpURLConnection
        while (true) {
            conn = URL(u).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; Linux aarch64) BedrockPhoneHost")
            if (hops == 0) headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            val c = conn.responseCode
            if (c in 301..308 && hops++ < 8) {
                u = URL(URL(u), conn.getHeaderField("Location")).toString(); conn.disconnect(); continue
            }
            if (c != 200) throw IOException("HTTP $c for $url")
            break
        }
        val total = conn.contentLengthLong
        conn.inputStream.use { i ->
            part.outputStream().use { o ->
                val buf = ByteArray(65536); var n: Int; var done = 0L; var last = 0L
                while (i.read(buf).also { n = it } >= 0) {
                    o.write(buf, 0, n); done += n
                    if (done - last > 524288) { onProgress(done, total); last = done }
                }
            }
        }
        dest.delete()
        if (!part.renameTo(dest)) throw IOException("Could not save ${dest.name}")
        onProgress(dest.length(), total)
    }

    fun getText(url: String, headers: Map<String, String> = emptyMap()): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000; conn.readTimeout = 30000
        conn.setRequestProperty("User-Agent", "BedrockPhoneHost")
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode} for $url")
        return conn.inputStream.bufferedReader().use { it.readText() }
    }

    fun unzip(zip: File, out: File) {
        out.mkdirs()
        val root = out.canonicalPath
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val f = File(out, e.name.replace('\\', '/'))
                if (f.canonicalPath.startsWith(root + File.separator)) {
                    if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { z.copyTo(it) } }
                }
                e = z.nextEntry
            }
        }
    }
}
