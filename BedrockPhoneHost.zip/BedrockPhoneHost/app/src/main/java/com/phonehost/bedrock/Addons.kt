package com.phonehost.bedrock

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Addon(val name: String, val type: String, val uuid: String, val version: List<Int>, val dir: String)

/** Installs Bedrock add-ons (.mcpack / .mcaddon / .zip): behavior packs and resource packs. */
class Addons(private val p: Paths) {
    private val db = File(p.serverDir, "addons.json")

    fun list(): List<Addon> = try {
        val a = JSONArray(db.readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Addon(o.getString("name"), o.getString("type"), o.getString("uuid"), ints(o.get("version")), o.getString("dir"))
        }
    } catch (e: Exception) { emptyList() }

    private fun ints(v: Any?): List<Int> = when (v) {
        is JSONArray -> (0 until v.length()).map { v.getInt(it) }
        is String -> v.split(".").mapNotNull { it.toIntOrNull() }.ifEmpty { listOf(1, 0, 0) }
        else -> listOf(1, 0, 0)
    }

    private fun save(l: List<Addon>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("name", it.name).put("type", it.type).put("uuid", it.uuid).put("version", JSONArray(it.version)).put("dir", it.dir)) }
        p.serverDir.mkdirs(); db.writeText(a.toString())
    }

    private fun worldFile(type: String): File {
        val level = Props(p).read()["level-name"] ?: "Bedrock level"
        return File(p.serverDir, "worlds/$level/" + if (type == "resource") "world_resource_packs.json" else "world_behavior_packs.json")
    }

    private fun editWorld(type: String, uuid: String, version: List<Int>?) {
        val f = worldFile(type); f.parentFile?.mkdirs()
        val arr = try { JSONArray(f.readText()) } catch (e: Exception) { JSONArray() }
        val out = JSONArray()
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); if (o.optString("pack_id") != uuid) out.put(o) }
        if (version != null) out.put(JSONObject().put("pack_id", uuid).put("version", JSONArray(version)))
        f.writeText(out.toString())
    }

    fun import(ctx: Context, uri: Uri): String {
        val work = File(ctx.cacheDir, "addon_" + System.nanoTime()).apply { mkdirs() }
        return try {
            val src = File(work, "src.zip")
            ctx.contentResolver.openInputStream(uri)!!.use { i -> src.outputStream().use { i.copyTo(it) } }
            val x = File(work, "x"); Net.unzip(src, x)
            val added = mutableListOf<Addon>()
            scan(x, added)
            if (added.isEmpty()) "No pack (manifest.json) found in that file."
            else {
                save(list().filter { o -> added.none { it.uuid == o.uuid } } + added)
                "Installed: " + added.joinToString { it.name + " (" + it.type + ")" } + ". Restart the server to apply."
            }
        } catch (e: Exception) { "Import failed: ${e.message}" } finally { work.deleteRecursively() }
    }

    private fun scan(dir: File, acc: MutableList<Addon>) {
        dir.walkTopDown().filter { it.isFile && it.extension.lowercase() in setOf("mcpack", "mcaddon", "zip") }.toList().forEach { f ->
            val d = File(f.parentFile, f.nameWithoutExtension + "_x")
            Net.unzip(f, d); f.delete(); scan(d, acc)
        }
        dir.walkTopDown().filter { it.isFile && it.name == "manifest.json" }.toList().forEach { m ->
            if (m.exists()) installPack(m.parentFile!!, acc)
        }
    }

    private fun installPack(root: File, acc: MutableList<Addon>) {
        val j = JSONObject(File(root, "manifest.json").readText())
        val h = j.getJSONObject("header")
        val uuid = h.getString("uuid")
        val ver = ints(h.opt("version"))
        var type = "behavior"
        j.optJSONArray("modules")?.let { m -> for (i in 0 until m.length()) if (m.getJSONObject(i).optString("type") == "resources") type = "resource" }
        var name = h.optString("name", root.name)
        if (name.isBlank() || name.startsWith("pack.")) name = root.name
        val dirName = name.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40) + "_" + uuid.take(6)
        val sub = if (type == "resource") "resource_packs" else "behavior_packs"
        val target = File(p.serverDir, "$sub/$dirName")
        target.deleteRecursively(); root.copyRecursively(target, true)
        editWorld(type, uuid, ver)
        acc += Addon(name, type, uuid, ver, "$sub/$dirName")
        root.deleteRecursively()
    }

    fun remove(a: Addon) {
        File(p.serverDir, a.dir).deleteRecursively()
        editWorld(a.type, a.uuid, null)
        save(list().filter { it.uuid != a.uuid })
    }
}
