package com.phonehost.bedrock

import java.net.Inet4Address
import java.net.Inet6Address
import java.net.NetworkInterface

object NetInfo {
    /** Returns (local IPv4, global IPv6). Either may be null. */
    fun addresses(): Pair<String?, String?> {
        var v4: String? = null
        var v6: String? = null
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
                if (!ni.isUp || ni.isLoopback) return@forEach
                ni.inetAddresses.toList().forEach { a ->
                    if (a is Inet4Address && a.isSiteLocalAddress && v4 == null) v4 = a.hostAddress
                    if (a is Inet6Address && !a.isLinkLocalAddress && !a.isLoopbackAddress && !a.isSiteLocalAddress && v6 == null)
                        v6 = a.hostAddress?.substringBefore('%')
                }
            }
        } catch (_: Exception) {}
        return v4 to v6
    }
}
