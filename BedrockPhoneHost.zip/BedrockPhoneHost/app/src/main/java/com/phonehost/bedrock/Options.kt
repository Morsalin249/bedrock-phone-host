package com.phonehost.bedrock

/**
 * kind: "step" (+/- number), "sel" (dropdown), "toggle" (check/cross), "text", "num" (digits only).
 * inv = the switch shows the opposite of the stored true/false value (like Aternos "Cracked").
 * tab/group decide where it is shown; adv = only visible when "Advanced" is switched on (search finds everything).
 * Keys checked against the Bedrock Dedicated Server 1.26.52 server.properties reference.
 */
data class Opt(
    val key: String, val label: String, val def: String, val kind: String,
    val tab: String, val group: String,
    val opts: List<String> = emptyList(), val inv: Boolean = false,
    val min: Int = 0, val max: Int = 9999, val hint: String = "", val info: String = "",
    val adv: Boolean = false
)

object Options {
    const val GENERAL = "General"
    const val PLAYERS = "Players"
    const val NETWORK = "Network"
    const val WORLD = "World"
    const val ADVANCED = "Advanced"

    val tabs = listOf(GENERAL, PLAYERS, NETWORK, WORLD, ADVANCED)

    val all = listOf(
        // ---- General
        Opt("server-name", "Server name", "Dedicated Server", "text", GENERAL, "Basics", info = "Shown in the server list. No semicolons."),
        Opt("max-players", "Slots", "10", "step", GENERAL, "Basics", min = 1, max = 100),
        Opt("gamemode", "Gamemode", "survival", "sel", GENERAL, "Basics", listOf("survival", "creative", "adventure")),
        Opt("difficulty", "Difficulty", "easy", "sel", GENERAL, "Basics", listOf("peaceful", "easy", "normal", "hard")),
        Opt("allow-cheats", "Allow cheats", "false", "toggle", GENERAL, "Basics", info = "Off = nobody can use slash commands in-game, even operators."),
        Opt("view-distance", "View distance", "6", "step", GENERAL, "Performance", min = 5, max = 32, info = "Biggest performance lever. Minimum is 5."),
        Opt("tick-distance", "Tick distance", "4", "step", GENERAL, "Performance", min = 4, max = 12),
        Opt("max-threads", "Max threads", "4", "step", GENERAL, "Performance", min = 1, max = 16),
        Opt("client-side-chunk-generation-enabled", "Client side chunk generation", "true", "toggle", GENERAL, "Performance", adv = true),

        // ---- Players
        Opt("online-mode", "Cracked (LAN play only)", "true", "toggle", PLAYERS, "Access", inv = true,
            info = "Remote players must always sign in to Xbox Live, whatever this is set to."),
        Opt("allow-list", "Allowlist", "true", "toggle", PLAYERS, "Access",
            info = "ON = only players on the allowlist can join (Players tab). Current Bedrock servers ship with this ON."),
        Opt("default-player-permission-level", "Default permission level", "member", "sel", PLAYERS, "Access", listOf("visitor", "member", "operator")),
        Opt("player-idle-timeout", "Idle kick (minutes, 0 = off)", "30", "num", PLAYERS, "Access"),
        Opt("allow-player-joining", "Allow joining", "true", "toggle", PLAYERS, "Access", adv = true, info = "Off = nobody can join unless an add-on script allows it."),
        Opt("chat-restriction", "Chat restriction", "None", "sel", PLAYERS, "Chat & skins", listOf("None", "Dropped", "Disabled")),
        Opt("disable-player-interaction", "Player interaction", "false", "toggle", PLAYERS, "Chat & skins", inv = true),
        Opt("disable-custom-skins", "Disable custom skins", "false", "toggle", PLAYERS, "Chat & skins", adv = true),

        // ---- Network
        Opt("transport", "Transport", "nethernet", "sel", NETWORK, "Connection", listOf("nethernet", "raknet"),
            info = "NetherNet is the only supported transport since Bedrock 26.50. Older versions use RakNet."),
        Opt("server-port", "Port (TCP signalling / IPv4)", "19132", "num", NETWORK, "Connection"),
        Opt("server-portv6", "IPv6 port (RakNet only)", "19133", "num", NETWORK, "Connection", adv = true),
        Opt("server-ip", "Bind address (NetherNet)", "", "text", NETWORK, "NetherNet", hint = "empty = all", adv = true),
        Opt("server-udp-ports", "UDP ports / NAT mapping", "", "text", NETWORK, "NetherNet", hint = "e.g. 19132:32000", adv = true,
            info = "Format [ip:]public[-public]:local[-local]. Use it when your tunnel forwards a fixed UDP port."),
        Opt("enable-lan-visibility", "Visible to LAN players", "true", "toggle", NETWORK, "Advanced network", adv = true),
        Opt("compression-algorithm", "Compression", "zlib", "sel", NETWORK, "Advanced network", listOf("zlib", "snappy"), adv = true),
        Opt("compression-threshold", "Compression threshold", "1", "num", NETWORK, "Advanced network", adv = true),
        Opt("enable-packet-rate-limiter", "Packet rate limiter", "false", "toggle", NETWORK, "Advanced network", adv = true),

        // ---- World
        Opt("level-name", "World name", "Bedrock level", "text", WORLD, "World", info = "Also the folder name under worlds/."),
        Opt("level-seed", "Seed", "", "text", WORLD, "World", hint = "Random", info = "Only used when the world is first created."),
        Opt("force-gamemode", "Force gamemode", "false", "toggle", WORLD, "World", info = "Needed for a gamemode change to affect an existing world."),
        Opt("texturepack-required", "Resource pack required", "false", "toggle", WORLD, "World"),

        // ---- Advanced
        Opt("server-authoritative-movement-strict", "Strict movement", "false", "toggle", ADVANCED, "Anti-cheat", adv = true),
        Opt("server-authoritative-dismount-strict", "Strict dismount", "false", "toggle", ADVANCED, "Anti-cheat", adv = true),
        Opt("server-authoritative-entity-interactions-strict", "Strict entity interactions", "false", "toggle", ADVANCED, "Anti-cheat", adv = true),
        Opt("server-authoritative-block-breaking", "Authoritative block breaking", "false", "toggle", ADVANCED, "Anti-cheat", adv = true),
        Opt("server-authoritative-block-breaking-pick-range-scalar", "Block breaking range scalar", "1.5", "text", ADVANCED, "Anti-cheat", adv = true, hint = "> 1.0"),
        Opt("player-position-acceptance-threshold", "Position acceptance threshold", "0.5", "text", ADVANCED, "Anti-cheat", adv = true),
        Opt("player-movement-action-direction-threshold", "Action direction threshold", "0.85", "text", ADVANCED, "Anti-cheat", adv = true),
        Opt("content-log-file-enabled", "Content log file", "false", "toggle", ADVANCED, "Logging", adv = true),
        Opt("content-log-console-output-enabled", "Content log in console", "false", "toggle", ADVANCED, "Logging", adv = true),
        Opt("content-log-level", "Content log level", "info", "sel", ADVANCED, "Logging", listOf("verbose", "info", "warning", "error"), adv = true),
        Opt("server-build-radius-ratio", "Build radius ratio", "Disabled", "text", ADVANCED, "Other", hint = "Disabled or 0.0-1.0", adv = true),
        Opt("block-network-ids-are-hashes", "Block network IDs are hashes", "true", "toggle", ADVANCED, "Other", adv = true)
    )

    fun groupsOf(tab: String): List<String> = all.filter { it.tab == tab }.map { it.group }.distinct()
}
