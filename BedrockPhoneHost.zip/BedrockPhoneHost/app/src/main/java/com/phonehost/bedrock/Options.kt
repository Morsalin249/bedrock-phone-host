package com.phonehost.bedrock

/**
 * kind: "step" (+/- number), "sel" (dropdown), "toggle" (check/cross), "text".
 * inv = the switch shows the opposite of the stored true/false value (like Aternos "Cracked").
 */
data class Opt(
    val key: String, val label: String, val def: String, val kind: String,
    val opts: List<String> = emptyList(), val inv: Boolean = false,
    val min: Int = 0, val max: Int = 9999, val hint: String = ""
)

object Options {
    // Same order and names as the Aternos Bedrock "Options" page.
    val main = listOf(
        Opt("max-players", "Slots", "10", "step", min = 1, max = 100),
        Opt("gamemode", "Gamemode", "survival", "sel", listOf("survival", "creative", "adventure")),
        Opt("difficulty", "Difficulty", "easy", "sel", listOf("peaceful", "easy", "normal", "hard")),
        Opt("online-mode", "Cracked (LAN play only)", "true", "toggle", inv = true),
        Opt("allow-cheats", "Allow Cheats", "false", "toggle"),
        Opt("force-gamemode", "Force Gamemode", "false", "toggle"),
        Opt("texturepack-required", "Resource pack required", "false", "toggle"),
        Opt("tick-distance", "Tick distance", "4", "step", min = 4, max = 12),
        Opt("transport", "Transport (nethernet after 26.60)", "raknet", "sel", listOf("raknet", "nethernet")),
        Opt("correct-player-movement", "Correct movement", "false", "toggle"),
        Opt("emit-server-telemetry", "Server telemetry", "false", "toggle"),
        Opt("default-player-permission-level", "Default player permission level", "member", "sel", listOf("visitor", "member", "operator")),
        Opt("op-permission-level", "OP permission level", "1", "step", min = 1, max = 4),
        Opt("server-authoritative-block-breaking", "Authoritative block breaking", "false", "toggle"),
        Opt("level-name", "World name", "Bedrock level", "text"),
        Opt("level-seed", "Seed", "", "text", hint = "Random"),
        Opt("level-type", "Worldtype", "DEFAULT", "sel", listOf("DEFAULT", "FLAT", "LEGACY")),
        Opt("view-distance", "View distance", "6", "step", min = 2, max = 32),
        Opt("content-log-file-enabled", "Content logging", "false", "toggle"),
        Opt("content-log-console-output-enabled", "Content log console output", "false", "toggle"),
        Opt("content-log-level", "Content log level", "info", "sel", listOf("verbose", "info", "warning", "error")),
        Opt("disable-player-interaction", "Player interaction", "false", "toggle", inv = true),
        Opt("chat-restriction", "Chat restriction", "None", "sel", listOf("None", "Dropped", "Disabled")),
        Opt("client-side-chunk-generation-enabled", "Client side chunk generation", "true", "toggle"),
        Opt("allow-list", "Allowlist", "false", "toggle")
    )

    // Extra Bedrock options that Aternos hides.
    val more = listOf(
        Opt("server-name", "Server name", "Dedicated Server", "text"),
        Opt("max-threads", "Max threads", "4", "step", min = 1, max = 16),
        Opt("player-idle-timeout", "Idle kick (minutes, 0 = off)", "30", "num"),
        Opt("server-authoritative-movement", "Movement authority", "server-auth", "sel", listOf("client-auth", "server-auth", "server-auth-with-rewind")),
        Opt("compression-algorithm", "Compression algorithm", "zlib", "sel", listOf("zlib", "snappy")),
        Opt("compression-threshold", "Compression threshold", "1", "num"),
        Opt("enable-lan-visibility", "Visible to LAN players", "true", "toggle"),
        Opt("block-network-ids-are-hashes", "Block network IDs are hashes", "true", "toggle"),
        Opt("disable-persona", "Disable persona skins", "false", "toggle"),
        Opt("disable-custom-skins", "Disable custom skins", "false", "toggle"),
        Opt("server-build-radius-ratio", "Build radius ratio", "Disabled", "text", hint = "Disabled or 0.0 to 1.0"),
        Opt("player-movement-score-threshold", "Movement score threshold", "20", "num"),
        Opt("player-movement-action-direction-threshold", "Action direction threshold", "0.85", "text"),
        Opt("player-movement-distance-threshold", "Distance threshold", "0.3", "text"),
        Opt("player-movement-duration-threshold-in-ms", "Duration threshold (ms)", "500", "num"),
        Opt("server-udp-ports", "UDP ports (NetherNet)", "", "text", hint = "IP:public:local"),
        Opt("server-port", "IPv4 port", "19132", "num"),
        Opt("server-portv6", "IPv6 port", "19133", "num")
    )

    val all: List<Opt> get() = main + more
}
