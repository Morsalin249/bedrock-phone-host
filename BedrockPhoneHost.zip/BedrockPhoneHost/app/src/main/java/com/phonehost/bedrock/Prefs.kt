package com.phonehost.bedrock

import android.content.Context
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("host", Context.MODE_PRIVATE)
    var version: String
        get() = sp.getString("version", "") ?: ""
        set(v) { sp.edit().putString("version", v).apply() }
    var useTunnel: Boolean
        get() = sp.getBoolean("tunnel", true)
        set(v) { sp.edit().putBoolean("tunnel", v).apply() }
    var playitSecret: String
        get() = sp.getString("secret", "") ?: ""
        set(v) { sp.edit().putString("secret", v.trim()).apply() }
    /** Server settings the user changed. Stored in the app, applied to server.properties on every start. */
    fun propOverrides(): Map<String, String> {
        val o = try { JSONObject(sp.getString("props", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        val m = LinkedHashMap<String, String>()
        o.keys().forEach { k -> val v = o.getString(k); if (v.isNotBlank() || k == "level-seed") m[k] = v }
        return m
    }
    fun setProp(k: String, v: String) {
        val o = try { JSONObject(sp.getString("props", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        o.put(k, v)
        sp.edit().putString("props", o.toString()).apply()
    }
    var worldLimitMb: Int
        get() = sp.getInt("wlimit", 0)
        set(v) { sp.edit().putInt("wlimit", v).apply() }
    var manualAddress: String
        get() = sp.getString("manual", "") ?: ""
        set(v) { sp.edit().putString("manual", v.trim()).apply() }
}
