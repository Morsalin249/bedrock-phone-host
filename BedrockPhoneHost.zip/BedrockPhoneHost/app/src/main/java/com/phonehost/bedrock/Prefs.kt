package com.phonehost.bedrock

import android.content.Context
import java.util.UUID

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("host", Context.MODE_PRIVATE)

    /** Shared secret between this app and the Termux backend. Generated once. */
    var token: String
        get() {
            val existing = sp.getString("token", null)
            if (existing != null) return existing
            val t = UUID.randomUUID().toString().replace("-", "")
            sp.edit().putString("token", t).apply()
            return t
        }
        set(v) { sp.edit().putString("token", v).apply() }

    var version: String
        get() = sp.getString("version", "") ?: ""
        set(v) { sp.edit().putString("version", v).apply() }
}
