package com.phonehost.bedrock

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("host", Context.MODE_PRIVATE)
    var version: String
        get() = sp.getString("version", "") ?: ""
        set(v) { sp.edit().putString("version", v).apply() }
    var useTunnel: Boolean
        get() = sp.getBoolean("tunnel", true)
        set(v) { sp.edit().putBoolean("tunnel", v).apply() }
    var playitSecret: String
        get() = sp.getString("secret", "") ?: ""
        set(v) { sp.edit().putString("secret", v.trim()).apply() }
    var worldLimitMb: Int
        get() = sp.getInt("wlimit", 0)
        set(v) { sp.edit().putInt("wlimit", v).apply() }
    var manualAddress: String
        get() = sp.getString("manual", "") ?: ""
        set(v) { sp.edit().putString("manual", v.trim()).apply() }
}
