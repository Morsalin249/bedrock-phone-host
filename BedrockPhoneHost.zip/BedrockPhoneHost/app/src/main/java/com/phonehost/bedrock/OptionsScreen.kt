package com.phonehost.bedrock

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private data class Tunnel(val id: String, val name: String, val address: String, val command: String, val enabled: Boolean)

@Composable
fun OptionsTab() {
    var cfg by remember { mutableStateOf<JSONObject?>(null) }
    LaunchedEffect(Unit) { cfg = withContext(Dispatchers.IO) { Api.get("/settings") } }
    val c = cfg
    if (c == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Loading...") }; return }
    OptionsBody(c)
}

/** One collapsible block of settings. */
@Composable
private fun Section(title: String, count: Int, closed: SnapshotStateMap<String, Boolean>, content: @Composable ColumnScope.() -> Unit) {
    val open = closed[title] != true
    GroupHeader(title, open, count) { closed[title] = open }
    if (open) Column(content = content)
}

@Composable
private fun OptSection(
    tab: String, group: String, advanced: Boolean, values: Map<String, String>, set: (String, String) -> Unit,
    closed: SnapshotStateMap<String, Boolean>, extra: @Composable ColumnScope.() -> Unit = {}
) {
    val list = Options.all.filter { it.tab == tab && it.group == group && (advanced || !it.adv) }
    if (list.isEmpty()) return
    Section(group, list.size, closed) {
        extra()
        list.forEach { OptControl(it, values, set) }
    }
}

@Composable
private fun OptionsBody(c: JSONObject) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val props = c.optJSONObject("props") ?: JSONObject()
    val values = remember {
        mutableStateMapOf<String, String>().also { m ->
            Options.all.forEach { o -> m[o.key] = if (props.has(o.key)) props.optString(o.key) else o.def }
        }
    }
    val set: (String, String) -> Unit = { k, v ->
        values[k] = v
        Api.later { Api.post("/settings", JSONObject().put("props", JSONObject().put(k, v))) }
    }
    var advanced by remember { mutableStateOf(prefs.advanced) }
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    val closed = remember { mutableStateMapOf<String, Boolean>() }

    var playit by remember { mutableStateOf(c.optBoolean("tunnel", false)) }
    var secret by remember { mutableStateOf(c.optString("secret")) }
    var limit by remember { mutableStateOf(c.optInt("world_limit_mb", 0).let { if (it > 0) it.toString() else "" }) }
    val tunnels = remember {
        mutableStateListOf<Tunnel>().also { l ->
            val a = c.optJSONArray("tunnels")
            for (i in 0 until (a?.length() ?: 0)) {
                val t = a!!.getJSONObject(i)
                l.add(Tunnel(t.optString("id"), t.optString("name"), t.optString("address"), t.optString("command"), t.optBoolean("enabled", true)))
            }
        }
    }
    fun saveTunnels() {
        val arr = JSONArray()
        tunnels.forEach { t ->
            arr.put(JSONObject().put("id", t.id).put("name", t.name).put("address", t.address).put("command", t.command).put("enabled", t.enabled))
        }
        Api.later { Api.post("/settings", JSONObject().put("tunnels", arr)) }
    }

    val tabs = if (advanced) Options.tabs else Options.tabs.filter { it != Options.ADVANCED }
    val tabIndex = tab.coerceIn(0, tabs.lastIndex)
    val searching = query.isNotBlank()

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Settings", Modifier.weight(1f), color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 22.sp)
                Text("Advanced", color = AtMuted, fontSize = 13.sp, modifier = Modifier.padding(end = 8.dp))
                AtToggle(advanced) { advanced = it; prefs.advanced = it }
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Search settings...") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
            Text("Saved automatically. Changes apply the next time you start the server.", color = AtMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
        }
        if (!searching) AtScrollTabs(tabs, tabIndex) { tab = it }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 6.dp)) {
            if (searching) {
                val q = query.trim().lowercase()
                val hits = Options.all.filter { o ->
                    o.key.lowercase().contains(q) || o.label.lowercase().contains(q) || o.hint.lowercase().contains(q) || o.info.lowercase().contains(q)
                }
                if (hits.isEmpty()) Text("Nothing found.", color = AtMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp))
                hits.forEach { o ->
                    Text("${o.tab} › ${o.group}", color = AtMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                    OptControl(o, values, set)
                }
            } else when (tabs[tabIndex]) {
                Options.GENERAL -> {
                    OptSection(Options.GENERAL, "Basics", advanced, values, set, closed)
                    OptSection(Options.GENERAL, "Performance", advanced, values, set, closed) {
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Profile:", color = Color.White, fontSize = 14.sp)
                            listOf("Low" to listOf("5", "4", "5", "2"), "Medium" to listOf("6", "4", "10", "4"), "High" to listOf("10", "6", "20", "8")).forEach { (n, v) ->
                                OutlinedButton(onClick = {
                                    set("view-distance", v[0]); set("tick-distance", v[1]); set("max-players", v[2]); set("max-threads", v[3])
                                }) { Text(n) }
                            }
                        }
                    }
                }
                Options.PLAYERS -> {
                    OptSection(Options.PLAYERS, "Access", advanced, values, set, closed)
                    OptSection(Options.PLAYERS, "Chat & skins", advanced, values, set, closed)
                }
                Options.NETWORK -> {
                    OptSection(Options.NETWORK, "Connection", advanced, values, set, closed)
                    Section("Tunnels", tunnels.size, closed) {
                        Text(
                            "Add any NetherNet tunnel service. Enter the public address players should join with. " +
                                "If the service has an agent or client that runs in Termux, put its start command too: it starts and stops with the server.",
                            color = AtMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                        )
                        tunnels.forEachIndexed { i, t ->
                            Panel(Modifier.padding(top = 8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Tunnel ${i + 1}", Modifier.weight(1f), fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, fontSize = 15.sp)
                                    AtToggle(t.enabled) { v -> tunnels[i] = t.copy(enabled = v); saveTunnels() }
                                }
                                OutlinedTextField(
                                    t.name, { v -> tunnels[i] = t.copy(name = v); saveTunnels() }, singleLine = true,
                                    label = { Text("Name (e.g. PortWarp)") }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                                )
                                OutlinedTextField(
                                    t.address, { v -> tunnels[i] = t.copy(address = v.trim()); saveTunnels() }, singleLine = true,
                                    label = { Text("Public address (host:port)") }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                                )
                                OutlinedTextField(
                                    t.command, { v -> tunnels[i] = t.copy(command = v); saveTunnels() },
                                    label = { Text("Start command (optional)") }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                                )
                                TextButton(onClick = { tunnels.removeAt(i); saveTunnels() }) { Text("Remove tunnel", color = AtRed) }
                            }
                        }
                        OutlinedButton(
                            onClick = { tunnels.add(Tunnel("t" + System.currentTimeMillis(), "Tunnel", "", "", true)); saveTunnels() },
                            modifier = Modifier.padding(top = 8.dp)
                        ) { Text("+ Add tunnel") }
                    }
                    OptSection(Options.NETWORK, "NetherNet", advanced, values, set, closed)
                    OptSection(Options.NETWORK, "Advanced network", advanced, values, set, closed)
                    if (advanced || playit) Section("Playit.gg (optional)", 2, closed) {
                        PlainRow("Start Playit with server") {
                            AtToggle(playit) { playit = it; Api.later { Api.post("/settings", JSONObject().put("tunnel", it)) } }
                        }
                        PlainRow("Playit secret key") {
                            AtField(secret, "optional", false) { secret = it; Api.later { Api.post("/settings", JSONObject().put("secret", it)) } }
                        }
                        Text("Built-in Playit.gg agent. Leave the secret empty to get a claim link on the Dashboard.", color = AtMuted, fontSize = 12.sp)
                    }
                }
                Options.WORLD -> {
                    OptSection(Options.WORLD, "World", advanced, values, set, closed)
                    Section("Storage", 1, closed) {
                        PlainRow("Stop if world exceeds (MB)") {
                            AtField(limit, "off", true) { t ->
                                limit = t.filter { ch -> ch.isDigit() }
                                Api.later { Api.post("/settings", JSONObject().put("world_limit_mb", limit.toIntOrNull() ?: 0)) }
                            }
                        }
                    }
                }
                else -> {
                    OptSection(Options.ADVANCED, "Anti-cheat", true, values, set, closed)
                    OptSection(Options.ADVANCED, "Logging", true, values, set, closed)
                    OptSection(Options.ADVANCED, "Other", true, values, set, closed)
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
