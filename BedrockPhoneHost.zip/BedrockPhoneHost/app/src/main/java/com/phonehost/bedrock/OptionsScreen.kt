package com.phonehost.bedrock

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
fun OptionsTab() {
    var cfg by remember { mutableStateOf<JSONObject?>(null) }
    LaunchedEffect(Unit) { cfg = withContext(Dispatchers.IO) { Api.get("/settings") } }
    val c = cfg
    if (c == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Loading...") }; return }
    OptionsBody(c)
}

@Composable
private fun OptionsBody(c: JSONObject) {
    val props = c.optJSONObject("props") ?: JSONObject()
    val values = remember {
        mutableStateMapOf<String, String>().also { m ->
            Options.all.forEach { o -> m[o.key] = if (props.has(o.key)) props.optString(o.key) else o.def }
        }
    }
    val set: (String, String) -> Unit = { k, v ->
        values[k] = v
        Api.later { Api.post("/settings", JSONObject().put("props", JSONObject().put(k, v))) }
    }
    var tunnel by remember { mutableStateOf(c.optBoolean("tunnel", true)) }
    var secret by remember { mutableStateOf(c.optString("secret")) }
    var manual by remember { mutableStateOf(c.optString("manual")) }
    var limit by remember { mutableStateOf(c.optInt("world_limit_mb", 0).let { if (it > 0) it.toString() else "" }) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        SectionTitle("Options")
        Text("Saved automatically. Changes apply the next time you start the server.", color = AtMuted, fontSize = 13.sp)

        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Performance:", color = Color.White, fontSize = 14.sp)
            listOf("Low" to listOf("5", "4", "5", "2"), "Medium" to listOf("6", "4", "10", "4"), "High" to listOf("10", "6", "20", "8")).forEach { (n, v) ->
                OutlinedButton(onClick = {
                    set("view-distance", v[0]); set("tick-distance", v[1]); set("max-players", v[2]); set("max-threads", v[3])
                }) { Text(n) }
            }
        }

        Spacer(Modifier.height(6.dp))
        Options.main.forEach { OptControl(it, values, set) }

        SectionTitle("Playit.gg tunnel")
        PlainRow("Start tunnel with server") {
            AtToggle(tunnel) { tunnel = it; Api.later { Api.post("/settings", JSONObject().put("tunnel", it)) } }
        }
        PlainRow("Playit secret key") {
            AtField(secret, "optional", false) { secret = it; Api.later { Api.post("/settings", JSONObject().put("secret", it)) } }
        }
        PlainRow("Public address") {
            AtField(manual, "host:port", false) { manual = it; Api.later { Api.post("/settings", JSONObject().put("manual", it.trim())) } }
        }
        Text("Leave the secret empty to get a claim link on the Server tab. The address is only needed if it does not show up by itself.", color = AtMuted, fontSize = 12.sp)

        SectionTitle("Storage")
        PlainRow("Stop if world exceeds (MB)") {
            AtField(limit, "off", true) { t ->
                limit = t.filter { ch -> ch.isDigit() }
                Api.later { Api.post("/settings", JSONObject().put("world_limit_mb", limit.toIntOrNull() ?: 0)) }
            }
        }

        SectionTitle("More options")
        Options.more.forEach { OptControl(it, values, set) }
        Spacer(Modifier.height(24.dp))
    }
}
