package com.phonehost.bedrock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Dark teal look with cyan accents.
val AtBg = Color(0xFF10191C)
val AtCard = Color(0xFF19272B)
val AtText = Color(0xFFE8F1F3)
val AtCtl = Color(0xFF0E171A)
val AtStrip = Color(0xFF141F23)
val AtGreen = Color(0xFF45D483)
val AtRed = Color(0xFFFF5A5F)
val AtOrange = Color(0xFFFFB02E)
val AtMuted = Color(0xFF93A8AE)
val AtCyan = Color(0xFF55D6E6)
val AtLime = Color(0xFFA5E86A)
val AtOnAccent = Color(0xFF06232A)

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = AtCard, contentColor = AtText, shape = RoundedCornerShape(14.dp), modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
}

/** A light row with a label and a dark control, plus the dark "key=value" strip underneath (as on Aternos). */
@Composable
fun OptRow(label: String, key: String, value: String, info: String = "", control: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)).background(AtCard)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f).padding(end = 8.dp)) {
                Text(label, color = AtText, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (info.isNotBlank()) Text(info, color = AtMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
            }
            control()
        }
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) { append(key) }
                append("=$value")
            },
            Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)).background(AtStrip).padding(horizontal = 14.dp, vertical = 6.dp),
            color = AtMuted, fontFamily = FontFamily.Monospace, fontSize = 13.sp
        )
    }
}

@Composable
fun PlainRow(label: String, control: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(12.dp)).background(AtCard).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f).padding(end = 8.dp), color = AtText, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        control()
    }
}

@Composable
fun AtToggle(on: Boolean, onChange: (Boolean) -> Unit) {
    Box(Modifier.width(74.dp).height(36.dp).clip(RoundedCornerShape(18.dp)).background(AtCtl).clickable { onChange(!on) }) {
        Box(
            Modifier.align(if (on) Alignment.CenterEnd else Alignment.CenterStart).width(36.dp).fillMaxHeight()
                .background(if (on) AtGreen else AtRed),
            contentAlignment = Alignment.Center
        ) { Text(if (on) "✓" else "✕", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
    }
}

@Composable
fun AtSelect(value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(10.dp)).background(AtCtl).clickable { open = true }.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(value.replaceFirstChar { it.uppercase() }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.width(10.dp))
            Text("⌄", color = Color.White, fontSize = 18.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false }) }
        }
    }
}

@Composable
fun AtStepper(value: String, min: Int, max: Int, onChange: (String) -> Unit) {
    val n = value.toIntOrNull() ?: min
    Row(Modifier.height(46.dp).clip(RoundedCornerShape(10.dp)).background(AtCtl)) {
        Box(Modifier.width(96.dp).fillMaxHeight().padding(end = 14.dp), contentAlignment = Alignment.CenterEnd) {
            Text(n.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Column(Modifier.width(42.dp).fillMaxHeight()) {
            Box(Modifier.weight(1f).fillMaxWidth().clickable { if (n < max) onChange((n + 1).toString()) }, contentAlignment = Alignment.Center) {
                Text("+", color = Color.White, fontSize = 20.sp)
            }
            Box(Modifier.weight(1f).fillMaxWidth().clickable { if (n > min) onChange((n - 1).toString()) }, contentAlignment = Alignment.Center) {
                Text("−", color = Color.White, fontSize = 20.sp)
            }
        }
    }
}

@Composable
fun AtField(value: String, hint: String, numeric: Boolean, onChange: (String) -> Unit) {
    Box(Modifier.width(190.dp).clip(RoundedCornerShape(10.dp)).background(AtCtl).padding(horizontal = 12.dp, vertical = 11.dp)) {
        if (value.isEmpty()) Text(hint, color = Color(0xFF7F8C97), fontWeight = FontWeight.Bold, fontSize = 16.sp)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold),
            cursorBrush = SolidColor(Color.White),
            keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun OptControl(o: Opt, values: Map<String, String>, set: (String, String) -> Unit) {
    val v = values[o.key] ?: o.def
    when (o.kind) {
        "toggle" -> {
            val on = (v == "true") != o.inv
            OptRow(o.label, o.key, v, o.info) { AtToggle(on) { n -> set(o.key, if (n != o.inv) "true" else "false") } }
        }
        "sel" -> OptRow(o.label, o.key, v, o.info) { AtSelect(v, o.opts) { set(o.key, it) } }
        "step" -> OptRow(o.label, o.key, v, o.info) { AtStepper(v, o.min, o.max) { set(o.key, it) } }
        "num" -> OptRow(o.label, o.key, v, o.info) { AtField(v, "", true) { t -> set(o.key, t.filter { c -> c.isDigit() }) } }
        else -> OptRow(o.label, o.key, v, o.info) { AtField(v, o.hint, false) { set(o.key, it) } }
    }
}


// ---------------------------------------------------------------- new dashboard building blocks

@Composable
fun AtBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    val f = fraction.coerceIn(0f, 1f)
    Box(modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(AtCtl)) {
        Box(Modifier.fillMaxWidth(f).fillMaxHeight().background(color))
    }
}

@Composable
fun StatCard(title: String, value: String, fraction: Float?, color: Color, modifier: Modifier = Modifier) {
    Surface(color = AtCard, contentColor = AtText, shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(title, fontSize = 12.sp, color = AtMuted, fontWeight = FontWeight.Bold)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
            if (fraction != null) AtBar(fraction, color) else Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
fun AtTabs(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(AtStrip)) {
        options.forEachIndexed { i, o ->
            Column(Modifier.weight(1f).clickable { onSelect(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    o, color = if (i == selected) AtCyan else AtMuted, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
                Box(Modifier.fillMaxWidth().height(3.dp).background(if (i == selected) AtCyan else Color.Transparent))
            }
        }
    }
}

@Composable
fun PillButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, container: Color = AtCyan, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled, shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = container, contentColor = AtOnAccent,
            disabledContainerColor = AtCtl, disabledContentColor = AtMuted
        ),
        modifier = modifier.height(46.dp)
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
}

@Composable
fun Avatar(name: String) {
    val palette = listOf(Color(0xFF26A69A), Color(0xFF7E57C2), Color(0xFF66BB6A), Color(0xFFEF5350), Color(0xFF42A5F5), Color(0xFFFFA726))
    val c = palette[(name.hashCode() and 0x7fffffff) % palette.size]
    Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(c), contentAlignment = Alignment.Center) {
        Text(name.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

fun logColor(line: String): Color = when {
    line.contains("ERROR") -> AtRed
    line.contains("WARN") -> AtOrange
    else -> Color(0xFFA8E6A1)
}


/** Tabs that scroll sideways when they do not fit. */
@Composable
fun AtScrollTabs(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(AtStrip).horizontalScroll(rememberScrollState())) {
        options.forEachIndexed { i, o ->
            Column(Modifier.clickable { onSelect(i) }.padding(horizontal = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    o.uppercase(), color = if (i == selected) AtCyan else AtMuted, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
                Box(Modifier.width(40.dp).height(3.dp).background(if (i == selected) AtCyan else Color.Transparent))
            }
        }
    }
}

/** Tap to fold / unfold a group of options. */
@Composable
fun GroupHeader(title: String, open: Boolean, count: Int, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(10.dp)).background(AtStrip).clickable { onToggle() }
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text("$count", color = AtMuted, fontSize = 13.sp)
        Spacer(Modifier.width(10.dp))
        Text(if (open) "▾" else "▸", color = AtCyan, fontSize = 18.sp)
    }
}
