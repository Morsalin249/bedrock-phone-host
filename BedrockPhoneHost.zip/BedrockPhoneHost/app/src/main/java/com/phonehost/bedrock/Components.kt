package com.phonehost.bedrock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Colours copied from the Aternos look.
val AtBg = Color(0xFF2B3945)
val AtCard = Color(0xFFEEEEEE)
val AtText = Color(0xFF1F2A33)
val AtCtl = Color(0xFF2D3A46)
val AtStrip = Color(0xFF222D37)
val AtGreen = Color(0xFF2ECC71)
val AtRed = Color(0xFFF0284A)
val AtOrange = Color(0xFFF39C12)
val AtMuted = Color(0xFFB9C4CC)

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = AtCard, contentColor = AtText, shape = RoundedCornerShape(6.dp), modifier = modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
}

/** A light row with a label and a dark control, plus the dark "key=value" strip underneath (as on Aternos). */
@Composable
fun OptRow(label: String, key: String, value: String, control: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)).background(AtCard)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, Modifier.weight(1f).padding(end = 8.dp), color = AtText, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            control()
        }
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) { append(key) }
                append("=$value")
            },
            Modifier.fillMaxWidth().background(AtStrip).padding(horizontal = 14.dp, vertical = 6.dp),
            color = AtMuted, fontFamily = FontFamily.Monospace, fontSize = 13.sp
        )
    }
}

@Composable
fun PlainRow(label: String, control: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(4.dp)).background(AtCard).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f).padding(end = 8.dp), color = AtText, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        control()
    }
}

@Composable
fun AtToggle(on: Boolean, onChange: (Boolean) -> Unit) {
    Box(Modifier.width(74.dp).height(36.dp).clip(RoundedCornerShape(4.dp)).background(AtCtl).clickable { onChange(!on) }) {
        Box(
            Modifier.align(if (on) Alignment.CenterEnd else Alignment.CenterStart).width(36.dp).fillMaxHeight()
                .background(if (on) AtGreen else AtRed),
            contentAlignment = Alignment.Center
        ) { Text(if (on) "✓" else "✕", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
    }
}

@Composable
fun AtSelect(value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(4.dp)).background(AtCtl).clickable { open = true }.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(value.replaceFirstChar { it.uppercase() }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.width(10.dp))
            Text("⌄", color = Color.White, fontSize = 18.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false }) }
        }
    }
}

@Composable
fun AtStepper(value: String, min: Int, max: Int, onChange: (String) -> Unit) {
    val n = value.toIntOrNull() ?: min
    Row(Modifier.height(46.dp).clip(RoundedCornerShape(4.dp)).background(AtCtl)) {
        Box(Modifier.width(96.dp).fillMaxHeight().padding(end = 14.dp), contentAlignment = Alignment.CenterEnd) {
            Text(n.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Column(Modifier.width(42.dp).fillMaxHeight()) {
            Box(Modifier.weight(1f).fillMaxWidth().clickable { if (n < max) onChange((n + 1).toString()) }, contentAlignment = Alignment.Center) {
                Text("+", color = Color.White, fontSize = 20.sp)
            }
            Box(Modifier.weight(1f).fillMaxWidth().clickable { if (n > min) onChange((n - 1).toString()) }, contentAlignment = Alignment.Center) {
                Text("−", color = Color.White, fontSize = 20.sp)
            }
        }
    }
}

@Composable
fun AtField(value: String, hint: String, numeric: Boolean, onChange: (String) -> Unit) {
    Box(Modifier.width(190.dp).clip(RoundedCornerShape(4.dp)).background(AtCtl).padding(horizontal = 12.dp, vertical = 11.dp)) {
        if (value.isEmpty()) Text(hint, color = Color(0xFF7F8C97), fontWeight = FontWeight.Bold, fontSize = 16.sp)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold),
            cursorBrush = SolidColor(Color.White),
            keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun OptControl(o: Opt, values: Map<String, String>, set: (String, String) -> Unit) {
    val v = values[o.key] ?: o.def
    when (o.kind) {
        "toggle" -> {
            val on = (v == "true") != o.inv
            OptRow(o.label, o.key, v) { AtToggle(on) { n -> set(o.key, if (n != o.inv) "true" else "false") } }
        }
        "sel" -> OptRow(o.label, o.key, v) { AtSelect(v, o.opts) { set(o.key, it) } }
        "step" -> OptRow(o.label, o.key, v) { AtStepper(v, o.min, o.max) { set(o.key, it) } }
        "num" -> OptRow(o.label, o.key, v) { AtField(v, "", true) { t -> set(o.key, t.filter { c -> c.isDigit() }) } }
        else -> OptRow(o.label, o.key, v) { AtField(v, o.hint, false) { set(o.key, it) } }
    }
}
