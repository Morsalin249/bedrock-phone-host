package com.phonehost.bedrock

import android.system.Os
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException

class Installer(
    private val p: Paths,
    private val log: (String) -> Unit,
    private val progress: (String) -> Unit
) {
    private val ansi = Regex("\u001B\\[[;?0-9]*[A-Za-z]")

    fun runtimeReady() = p.marker.exists() && p.proot.exists()
    fun installedVersion() = if (p.versionFile.exists()) p.versionFile.readText().trim() else ""

    private fun prog(what: String) = { d: Long, t: Long ->
        progress(if (t > 0) "$what ${d * 100 / t}% (${d / 1048576} MB)" else "$what ${d / 1048576} MB")
    }

    private fun runInProot(script: String): Int {
        val pr = p.process(script, "/").start()
        pr.inputStream.bufferedReader().forEachLine { log(ansi.replace(it, "")) }
        return pr.waitFor()
    }

    fun setupRuntime() {
        log("== Setting up Linux runtime (one time, needs internet) ==")
        if (!p.proot.exists() || p.proot.length() < 1000) {
            log("Downloading proot...")
            Net.download(Config.PROOT_URL, p.proot, prog("proot"))
        }
        Os.chmod(p.proot.absolutePath, 493) // 0755

        if (!p.rootfsOk.exists()) {
            p.rootfs.deleteRecursively()
            val tar = File(p.cache, "rootfs.tar.xz")
            log("Downloading Debian arm64 root filesystem...")
            Net.download(Config.ROOTFS_URL, tar, prog("rootfs"))
            log("Extracting (takes a minute)...")
            extractTarXz(tar, p.rootfs)
            tar.delete()
            p.rootfsOk.writeText("ok")
        }
        for (d in listOf("tmp", "root", "srv/bedrock", "usr/local/bin", "etc")) File(p.rootfs, d).mkdirs()
        File(p.rootfs, "etc/resolv.conf").writeText("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
        File(p.rootfs, "etc/hosts").writeText("127.0.0.1 localhost\n::1 localhost\n")

        log("Installing box64 (x86_64 emulator) and libraries...")
        val rc = runInProot(
            """
            export DEBIAN_FRONTEND=noninteractive
            echo 'APT::Sandbox::User "root";' > /etc/apt/apt.conf.d/01sandbox
            chmod 1777 /tmp
            dpkg --add-architecture amd64
            apt-get update || exit 10
            apt-get install -y --no-install-recommends ca-certificates box64 || exit 11
            apt-get install -y --no-install-recommends libc6:amd64 libstdc++6:amd64 zlib1g:amd64 libcurl4t64:amd64 || exit 12
            command -v box64 >/dev/null || exit 13
            """.trimIndent()
        )
        if (rc != 0) throw IOException(
            "Runtime setup failed (code $rc). 10=apt update, 11=box64 not in repo, 12=x86_64 libs. See console log above."
        )

        log("Downloading Playit.gg agent...")
        Net.download(Config.PLAYIT_URL, p.playit, prog("playit"))
        Os.chmod(p.playit.absolutePath, 493)

        p.marker.writeText("ok")
        progress("")
        log("== Runtime ready ==")
    }

    fun installBedrock(version: String) {
        log("== Installing Bedrock server $version ==")
        p.serverDir.mkdirs()
        val zip = File(p.cache, "bds.zip")
        try {
            Net.download(Config.bdsUrl(version), zip, prog("bedrock $version"))
        } catch (e: IOException) {
            throw IOException("Could not download version $version (${e.message}). Check the exact version number, e.g. 1.21.50.07")
        }
        val tmp = File(p.cache, "bds_x").also { it.deleteRecursively() }
        Net.unzip(zip, tmp)
        zip.delete()

        val firstInstall = !p.versionFile.exists()
        val managed = Addons(p).list().map { it.dir }.toSet()
        for (sub in listOf("behavior_packs", "resource_packs"))
            File(p.serverDir, sub).listFiles()?.forEach { if ("$sub/${it.name}" !in managed) it.deleteRecursively() }

        val keep = setOf("server.properties", "allowlist.json", "permissions.json")
        tmp.walkTopDown().filter { it.isFile }.forEach { f ->
            val rel = f.relativeTo(tmp).path
            val dest = File(p.serverDir, rel)
            if (rel in keep && dest.exists()) return@forEach
            dest.parentFile?.mkdirs()
            f.copyTo(dest, overwrite = true)
        }
        tmp.deleteRecursively()
        File(p.serverDir, "bedrock_server").let { if (it.exists()) Os.chmod(it.absolutePath, 493) }
        if (firstInstall) Props(p).write(mapOf("view-distance" to "6", "tick-distance" to "4"))
        p.versionFile.writeText(version)
        progress("")
        log("== Installed $version ==")
    }

    private fun extractTarXz(src: File, dest: File) {
        dest.mkdirs()
        val root = dest.canonicalPath
        TarArchiveInputStream(XZCompressorInputStream(BufferedInputStream(FileInputStream(src), 1 shl 16))).use { tin ->
            var e = tin.nextTarEntry
            var n = 0
            while (e != null) {
                val name = e.name.removePrefix("./").trimEnd('/')
                if (name.isNotEmpty()) {
                    val out = File(dest, name)
                    if (out.absolutePath.startsWith(root)) {
                        when {
                            e.isDirectory -> { out.mkdirs(); Os.chmod(out.absolutePath, e.mode or 448) }
                            e.isSymbolicLink -> {
                                out.parentFile?.mkdirs(); out.delete()
                                try { Os.symlink(e.linkName, out.absolutePath) } catch (_: Exception) {}
                            }
                            e.isLink -> {
                                val target = File(dest, e.linkName.removePrefix("./"))
                                out.parentFile?.mkdirs()
                                if (target.exists()) target.copyTo(out, overwrite = true)
                            }
                            e.isFile -> {
                                out.parentFile?.mkdirs()
                                out.outputStream().use { tin.copyTo(it) }
                                Os.chmod(out.absolutePath, e.mode or 384)
                            }
                        }
                    }
                }
                if (++n % 2000 == 0) progress("extracting... $n files")
                e = tin.nextTarEntry
            }
        }
        progress("")
    }
}
