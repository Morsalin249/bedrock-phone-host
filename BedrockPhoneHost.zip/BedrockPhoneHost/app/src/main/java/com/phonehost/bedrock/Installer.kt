package com.phonehost.bedrock

import android.system.Os
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.json.JSONObject
import java.io.InputStream
import java.util.zip.GZIPInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException

class Installer(
    private val p: Paths,
    private val log: (String) -> Unit,
    private val progress: (String) -> Unit
) {
    private val ansi = Regex("\u001B\\[[;?0-9]*[A-Za-z]")

    fun runtimeReady() = p.marker.exists() && p.proot.exists()
    fun installedVersion() = if (p.versionFile.exists()) p.versionFile.readText().trim() else ""

    private fun prog(what: String) = { d: Long, t: Long ->
        progress(if (t > 0) "$what ${d * 100 / t}% (${d / 1048576} MB)" else "$what ${d / 1048576} MB")
    }

    private var lastOut = ""

    private fun runInProot(script: String, verbose: Int = 0, quiet: Boolean = false): Int {
        val pr = p.process(script, "/", verbose).start()
        val sb = StringBuilder()
        pr.inputStream.bufferedReader().forEachLine { val l = ansi.replace(it, ""); sb.appendLine(l); if (!quiet) log(l) }
        lastOut = sb.toString()
        return pr.waitFor()
    }

    private fun sanity(): Boolean = try {
        runInProot("echo SANITY_OK", 0, true) == 0 && lastOut.contains("SANITY_OK")
    } catch (e: Exception) { lastOut = e.message ?: "error"; false }

    private fun installRootfs(tag: String) {
        if (p.rootfsOk.exists() && p.rootfsOk.readText() == tag) return
        p.rootfsOk.delete()
        p.rootfs.deleteRecursively()
        log("Downloading Debian ($tag) arm64 root filesystem from Docker Hub...")
        for ((i, layer) in dockerLayers(tag).withIndex()) {
            val tar = File(p.cache, "rootfs_layer$i.tar")
            Net.download("https://registry-1.docker.io/v2/${Config.DOCKER_REPO}/blobs/${layer.first}", tar, prog("rootfs"), layer.second)
            log("Extracting (takes a minute)...")
            extractTar(tar, p.rootfs)
            tar.delete()
        }
        for (d in listOf("tmp", "root", "srv/bedrock", "usr/local/bin", "etc")) File(p.rootfs, d).mkdirs()
        File(p.rootfs, "etc/resolv.conf").writeText("nameserver 1.1.1.1\nnameserver 8.8.8.8\n")
        File(p.rootfs, "etc/hosts").writeText("127.0.0.1 localhost\n::1 localhost\n")
        p.rootfsOk.writeText(tag)
    }

    fun setupRuntime() {
        log("== Setting up Linux runtime (one time, needs internet) ==")
        var ok = false
        for (tag in Config.DOCKER_TAGS) {
            installRootfs(tag)
            for (url in Config.PROOT_URLS) {
                val name = url.substringAfterLast('/')
                log("Testing $name with $tag...")
                try {
                    Net.download(url, p.proot, prog("proot"))
                } catch (e: IOException) { log("  skipped: ${e.message}"); continue }
                Os.chmod(p.proot.absolutePath, 493) // 0755
                if (sanity()) { ok = true; log("Linux starts: $name + $tag"); break }
                log("  failed: " + lastOut.lines().filter { it.isNotBlank() }.takeLast(2).joinToString(" | "))
            }
            if (ok) break
        }
        if (!ok) {
            log("--- diagnostics (end of verbose run) ---")
            try { runInProot("echo SANITY_OK", 5, true) } catch (_: Exception) {}
            lastOut.lines().filter { it.isNotBlank() }.takeLast(30).forEach { log(it) }
            throw IOException("Linux could not start on this phone. Send a screenshot of this console.")
        }

        log("Installing box64 (x86_64 emulator) and libraries...")
        val rc = runInProot(
            """
            set -x
            export DEBIAN_FRONTEND=noninteractive
            echo 'APT::Sandbox::User "root";' > /etc/apt/apt.conf.d/01sandbox
            chmod 1777 /tmp
            dpkg --add-architecture amd64
            apt-get update || exit 10
            apt-get install -y --no-install-recommends ca-certificates box64 || exit 11
            apt-get install -y --no-install-recommends libc6:amd64 libstdc++6:amd64 zlib1g:amd64 libcurl4t64:amd64 || apt-get install -y --no-install-recommends libc6:amd64 libstdc++6:amd64 zlib1g:amd64 libcurl4:amd64 || exit 12
            command -v box64 >/dev/null || exit 13
            """.trimIndent()
        )
        if (rc != 0) throw IOException(
            "Runtime setup failed (code $rc). 10=apt update, 11=box64 not in repo, 12=x86_64 libs. See console log above."
        )

        log("Downloading Playit.gg agent...")
        Net.download(Config.PLAYIT_URL, p.playit, prog("playit"))
        Os.chmod(p.playit.absolutePath, 493)

        p.marker.writeText("ok")
        progress("")
        log("== Runtime ready ==")
    }

    fun installBedrock(version: String) {
        log("== Installing Bedrock server $version ==")
        p.serverDir.mkdirs()
        val zip = File(p.cache, "bds.zip")
        try {
            Net.download(Config.bdsUrl(version), zip, prog("bedrock $version"))
        } catch (e: IOException) {
            throw IOException("Could not download version $version (${e.message}). Check the exact version number, e.g. 1.21.50.07")
        }
        val tmp = File(p.cache, "bds_x").also { it.deleteRecursively() }
        Net.unzip(zip, tmp)
        zip.delete()

        val firstInstall = !p.versionFile.exists()
        val managed = Addons(p).list().map { it.dir }.toSet()
        for (sub in listOf("behavior_packs", "resource_packs"))
            File(p.serverDir, sub).listFiles()?.forEach { if ("$sub/${it.name}" !in managed) it.deleteRecursively() }

        val keep = setOf("server.properties", "allowlist.json", "permissions.json")
        tmp.walkTopDown().filter { it.isFile }.forEach { f ->
            val rel = f.relativeTo(tmp).path
            val dest = File(p.serverDir, rel)
            if (rel in keep && dest.exists()) return@forEach
            dest.parentFile?.mkdirs()
            f.copyTo(dest, overwrite = true)
        }
        tmp.deleteRecursively()
        File(p.serverDir, "bedrock_server").let { if (it.exists()) Os.chmod(it.absolutePath, 493) }
        if (firstInstall) Props(p).write(mapOf("view-distance" to "6", "tick-distance" to "4"))
        p.versionFile.writeText(version)
        progress("")
        log("== Installed $version ==")
    }

    /** Returns (blob digest, auth headers) for each layer of the arm64 Debian image. */
    private fun dockerLayers(tag: String): List<Pair<String, Map<String, String>>> {
        val repo = Config.DOCKER_REPO
        val tok = JSONObject(Net.getText("https://auth.docker.io/token?service=registry.docker.io&scope=repository:$repo:pull")).getString("token")
        val auth = mapOf("Authorization" to "Bearer $tok")
        val accept = "application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json, " +
            "application/vnd.oci.image.manifest.v1+json, application/vnd.docker.distribution.manifest.v2+json"
        val base = "https://registry-1.docker.io/v2/$repo/manifests/"
        var m = JSONObject(Net.getText(base + tag, auth + ("Accept" to accept)))
        if (m.has("manifests")) {
            val arr = m.getJSONArray("manifests")
            var digest: String? = null
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val pl = e.optJSONObject("platform") ?: continue
                if (pl.optString("architecture") == "arm64" && pl.optString("os") == "linux") { digest = e.getString("digest"); break }
            }
            if (digest == null) throw IOException("No arm64 image found for $tag")
            m = JSONObject(Net.getText(base + digest, auth + ("Accept" to accept)))
        }
        val layers = m.getJSONArray("layers")
        return (0 until layers.length()).map { layers.getJSONObject(it).getString("digest") to auth }
    }

    private fun openTar(src: File): InputStream {
        val raw = BufferedInputStream(FileInputStream(src), 1 shl 16)
        raw.mark(8)
        val b0 = raw.read(); val b1 = raw.read()
        raw.reset()
        return when {
            b0 == 0x1f && b1 == 0x8b -> GZIPInputStream(raw, 1 shl 16)
            b0 == 0xfd -> XZCompressorInputStream(raw)
            else -> raw
        }
    }

    private fun extractTar(src: File, dest: File) {
        dest.mkdirs()
        val root = dest.canonicalPath
        TarArchiveInputStream(openTar(src)).use { tin ->
            var e = tin.nextTarEntry
            var n = 0
            while (e != null) {
                val name = e.name.removePrefix("./").trimEnd('/')
                if (name.isNotEmpty()) {
                    val out = File(dest, name)
                    if (out.absolutePath.startsWith(root)) {
                        when {
                            e.isDirectory -> { out.mkdirs(); Os.chmod(out.absolutePath, e.mode or 448) }
                            e.isSymbolicLink -> {
                                out.parentFile?.mkdirs(); out.delete()
                                try { Os.symlink(e.linkName, out.absolutePath) } catch (_: Exception) {}
                            }
                            e.isLink -> {
                                val target = File(dest, e.linkName.removePrefix("./"))
                                out.parentFile?.mkdirs()
                                if (target.exists()) target.copyTo(out, overwrite = true)
                            }
                            e.isFile -> {
                                out.parentFile?.mkdirs()
                                out.outputStream().use { tin.copyTo(it) }
                                Os.chmod(out.absolutePath, e.mode or 384)
                            }
                        }
                    }
                }
                if (++n % 2000 == 0) progress("extracting... $n files")
                e = tin.nextTarEntry
            }
        }
        progress("")
    }
}
