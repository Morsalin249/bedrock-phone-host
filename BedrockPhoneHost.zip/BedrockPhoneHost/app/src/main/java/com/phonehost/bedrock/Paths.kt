package com.phonehost.bedrock

import android.content.Context
import java.io.File

class Paths(ctx: Context) {
    val base: File = ctx.filesDir
    val cache: File = ctx.cacheDir
    val proot = File(base, "proot")
    val rootfs = File(base, "rootfs")
    val rootfsOk = File(base, "rootfs.ok")
    val marker = File(base, "runtime.ok")
    val tmp = File(ctx.cacheDir, "proot-tmp").also { it.mkdirs() }
    val serverDir = File(rootfs, "srv/bedrock")
    val playit = File(rootfs, "usr/local/bin/playit")
    val versionFile = File(serverDir, "installed_version.txt")

    fun cmd(inner: String, cwd: String = "/srv/bedrock", verbose: Boolean = false) = listOf(
        proot.absolutePath, *(if (verbose) arrayOf<String>("-v", "1") else arrayOf<String>()), "--link2symlink", "-0", "-r", rootfs.absolutePath,
        "-b", "/dev", "-b", "/proc", "-b", "/sys", "-w", cwd,
        "/usr/bin/env", "-i", "HOME=/root", "LANG=C.UTF-8", "TERM=xterm",
        "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "BOX64_LOG=0",
        "BOX64_LD_LIBRARY_PATH=/srv/bedrock:/usr/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu",
        "/bin/sh", "-c", inner
    )

    fun process(inner: String, cwd: String = "/srv/bedrock", verbose: Boolean = false): ProcessBuilder =
        ProcessBuilder(cmd(inner, cwd, verbose)).redirectErrorStream(true).also {
            it.environment()["PROOT_TMP_DIR"] = tmp.absolutePath
            it.environment()["PROOT_NO_SECCOMP"] = "1"
        }
}
