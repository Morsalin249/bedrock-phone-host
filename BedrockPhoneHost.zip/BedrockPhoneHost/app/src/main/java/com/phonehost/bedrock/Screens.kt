package com.phonehost.bedrock

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

private fun cmd(c: String) { Api.later { Api.post("/cmd", JSONObject().put("cmd", c)) } }

private fun copyToCache(ctx: Context, uri: Uri): File {
    val f = File(ctx.cacheDir, "up_" + System.nanoTime())
    ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
    return f
}

private fun battery(ctx: Context): Pair<Int, Float> {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    return (if (lvl >= 0) lvl * 100 / scale else 0) to ((i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f)
}

@Composable
private fun AddrRow(label: String, value: String?, onCopy: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 12.sp, color = AtMuted)
            Text(value ?: "not available", fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        if (value != null) TextButton(onClick = { onCopy(value) }) { Text("Copy") }
    }
}

private fun fmtUptime(secs: Long): String = "%d:%02d:%02d".format(secs / 3600, secs % 3600 / 60, secs % 60)

private fun since(nowMs: Long, epochSec: Double): String {
    if (epochSec <= 0.0) return ""
    val m = (nowMs / 1000 - epochSec.toLong()) / 60
    return when {
        m < 1 -> "just now"
        m < 60 -> "$m min ago"
        else -> "${m / 60} h ago"
    }
}

@Composable
fun ServerTab(onConsole: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val prefs = remember { Prefs(ctx) }
    val st by Model.state.collectAsState()
    val logs by Model.logs.collectAsState()
    val s = st
    if (s == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Loading...") }; return }

    val status = s.optString("status", "stopped")
    var version by remember { mutableStateOf(prefs.version.ifBlank { s.optString("version") }) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    var storage by remember { mutableStateOf<JSONObject?>(null) }
    LaunchedEffect(status) { storage = withContext(Dispatchers.IO) { Api.get("/storage") } }

    val (label, color) = when (status) {
        "running" -> "Online" to AtGreen
        "starting" -> "Starting..." to AtOrange
        "installing" -> "Installing..." to AtOrange
        "stopping" -> "Stopping..." to AtOrange
        else -> "Offline" to AtRed
    }
    val valid = (Regex("^\\d+(\\.\\d+){2,3}$").matches(version.trim()) || version.trim().equals("latest", ignoreCase = true))
    val players = s.optJSONArray("players")
    val playerList = (0 until (players?.length() ?: 0)).map { players!!.getString(it) }
    val maxPlayers = s.optString("max_players", "10").toIntOrNull() ?: 10
    val playit = s.optJSONObject("playit")
    val playitAddr = playit?.optString("address") ?: ""
    val tunnelArr = s.optJSONArray("tunnels")
    val tunnelList = (0 until (tunnelArr?.length() ?: 0)).map { tunnelArr!!.getJSONObject(it) }
        .filter { it.optBoolean("enabled", true) && it.optString("address").isNotBlank() }
    val claim = playit?.optString("claim") ?: ""
    val transport = s.optString("transport", "nethernet")
    val port = s.optString("port", "19132").ifBlank { "19132" }
    val portv6 = s.optString("portv6", "19133").ifBlank { "19133" }
    val ips = s.optJSONObject("ips")
    val v4 = ips?.optString("v4")?.takeIf { it.isNotBlank() && it != "null" }
    val v6 = ips?.optString("v6")?.takeIf { it.isNotBlank() && it != "null" }
    val started = s.optDouble("started", 0.0)
    val res = s.optJSONObject("resources")
    val ramMb = res?.optLong("ram_mb", -1L) ?: -1L
    val memTotalMb = res?.optLong("mem_total_mb", 0L) ?: 0L
    val cpu = res?.optDouble("cpu", -1.0) ?: -1.0
    val up = if (status == "running" && started > 0) (now / 1000 - started.toLong()).coerceAtLeast(0) else -1L
    val canRestart = status == "running" || status == "starting"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(color = AtCard, contentColor = AtText, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(color))
                    Spacer(Modifier.width(8.dp))
                    Text("Server Status: ", fontSize = 16.sp)
                    Text(label.uppercase(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = color)
                }
                val prog = s.optString("progress")
                if (prog.isNotBlank()) Text(prog, color = AtMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        enabled = (status == "stopped" && valid) || status == "running" || status == "starting",
                        shape = RoundedCornerShape(26.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (status == "stopped") AtLime else AtCyan, contentColor = AtOnAccent,
                            disabledContainerColor = AtCtl, disabledContentColor = AtMuted
                        ),
                        modifier = Modifier.weight(1f).height(52.dp),
                        onClick = {
                            if (status == "stopped") {
                                prefs.version = version.trim()
                                scope.launch(Dispatchers.IO) { Api.post("/start", JSONObject().put("version", version.trim())) }
                            } else scope.launch(Dispatchers.IO) { Api.post("/stop") }
                        }
                    ) { Text(if (status == "stopped") "START SERVER" else "STOP SERVER", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(10.dp))
                    Column(
                        Modifier.clip(RoundedCornerShape(10.dp))
                            .clickable(enabled = canRestart) { scope.launch(Dispatchers.IO) { Api.post("/restart", JSONObject().put("version", version.trim())) } }
                            .alpha(if (canRestart) 1f else 0.35f)
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("⟳", fontSize = 24.sp, color = AtCyan)
                        Text("RESTART", fontSize = 10.sp, color = AtCyan, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("PLAYERS", "${playerList.size}/$maxPlayers", playerList.size.toFloat() / maxPlayers.coerceAtLeast(1), AtCyan, Modifier.weight(1f))
            StatCard(
                "RAM", if (ramMb >= 0 && memTotalMb > 0) "%.1f / %.0f GB".format(ramMb / 1024.0, memTotalMb / 1024.0) else "—",
                if (ramMb >= 0 && memTotalMb > 0) ramMb.toFloat() / memTotalMb else 0f, AtGreen, Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("CPU", if (cpu >= 0) "%d%%".format(cpu.toInt()) else "—", if (cpu >= 0) (cpu / 100.0).toFloat() else 0f, AtOrange, Modifier.weight(1f))
            StatCard("UPTIME", if (up >= 0) fmtUptime(up) else "—", null, AtLime, Modifier.weight(1f))
        }

        Surface(color = AtCard, contentColor = AtText, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Row(Modifier.fillMaxWidth().clickable { onConsole() }, verticalAlignment = Alignment.CenterVertically) {
                    Text("RECENT LOGS", fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("OPEN ▸", color = AtCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.padding(top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(AtCtl).padding(10.dp)) {
                    val recent = logs.takeLast(8)
                    if (recent.isEmpty()) Text("No output yet", fontSize = 12.sp, color = AtMuted)
                    recent.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = logColor(it), maxLines = 2) }
                }
            }
        }

        Panel {
            Text("Software", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            OutlinedTextField(
                value = version, onValueChange = { version = it }, enabled = status == "stopped", singleLine = true,
                label = { Text("Minecraft Bedrock version") }, placeholder = { Text("e.g. 1.26.52.3 or latest") },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
            Text("Installed: " + s.optString("installed_version").ifBlank { "nothing yet" } +
                ". Players must use the same Minecraft version. The first start downloads about 300 MB.", fontSize = 12.sp, color = AtMuted, modifier = Modifier.padding(top = 6.dp))
        }
        Panel {
            Text("Address", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            tunnelList.forEach { t ->
                AddrRow(t.optString("name") + (if (t.optBoolean("running")) " (agent running)" else ""), t.optString("address")) { clip.setText(AnnotatedString(it)) }
            }
            if (playitAddr.isNotBlank()) AddrRow("Playit.gg", playitAddr) { clip.setText(AnnotatedString(it)) }
            if (tunnelList.isEmpty() && playitAddr.isBlank()) {
                Text("No tunnel yet. Add one in Settings > Network > Tunnels.", fontSize = 12.sp, color = AtMuted, modifier = Modifier.padding(top = 8.dp))
            }
            AddrRow("Wi-Fi (same network)", v4?.let { "$it:$port" }) { clip.setText(AnnotatedString(it)) }
            if (transport == "raknet") AddrRow("IPv6 (direct)", v6?.let { "[$it]:$portv6" }) { clip.setText(AnnotatedString(it)) }
            if (claim.isNotBlank()) {
                Text("Link your Playit account, then add a Minecraft Bedrock tunnel for this agent:", fontSize = 12.sp, color = AtMuted, modifier = Modifier.padding(top = 8.dp))
                TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(claim))) }) { Text("Open Playit claim link") }
            }
        }
        Panel {
            Text("Storage", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            val sg = storage
            if (sg == null) Text("Calculating...", fontSize = 13.sp, color = AtMuted) else {
                Text("World: ${fmtSize(sg.optLong("world"))}", fontSize = 13.sp)
                Text("Server files: ${fmtSize(sg.optLong("server"))}   Linux: ${fmtSize(sg.optLong("runtime"))}", fontSize = 13.sp)
                Text("Phone free space: ${fmtSize(sg.optLong("free"))}", fontSize = 13.sp)
                if (sg.optLong("free") < 1073741824L) Text("Low space! The server may crash.", fontSize = 13.sp, color = AtRed)
            }
        }
        val (pct, temp) = remember(now / 5000) { battery(ctx) }
        Panel {
            Text("Phone", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Battery $pct%  •  ${"%.1f".format(temp)}°C", fontSize = 13.sp)
            Text("Set Termux to 'Don't optimize' / 'No restrictions' so Android does not stop the server.", fontSize = 12.sp, color = AtMuted, modifier = Modifier.padding(top = 4.dp))
            Row {
                TextButton(onClick = { Termux.openApp(ctx) }) { Text("Open Termux") }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Battery settings") }
            }
        }
        Text("By installing a server you accept the Minecraft EULA (minecraft.net/eula).", fontSize = 11.sp, color = AtMuted)
    }
}

@Composable
fun ConsoleTab() {
    val logs by Model.logs.collectAsState()
    val state = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    val send = { if (text.isNotBlank()) { cmd(text.trim()); text = "" } }
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) state.scrollToItem(logs.lastIndex) }
    Column(Modifier.fillMaxSize().padding(10.dp)) {
        Surface(color = AtCtl, contentColor = AtText, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(Modifier.padding(10.dp), state = state) {
                items(logs) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = logColor(it)) }
            }
        }
        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                text, { text = it }, Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(14.dp),
                placeholder = { Text("command, e.g. op Steve") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() })
            )
            Spacer(Modifier.width(8.dp))
            PillButton("SEND") { send() }
        }
    }
}

@Composable
private fun PlayerRow(name: String, joined: String) {
    var open by remember { mutableStateOf(false) }
    Surface(color = AtCard, contentColor = AtText, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(name)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Player", fontSize = 12.sp, color = AtMuted)
            }
            Text(joined, fontSize = 12.sp, color = AtMuted)
            Box {
                Text("⋮", fontSize = 22.sp, modifier = Modifier.clickable { open = true }.padding(horizontal = 10.dp, vertical = 4.dp))
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    DropdownMenuItem(text = { Text("Op") }, onClick = { cmd("op \"$name\""); open = false })
                    DropdownMenuItem(text = { Text("Deop") }, onClick = { cmd("deop \"$name\""); open = false })
                    DropdownMenuItem(text = { Text("Kick") }, onClick = { cmd("kick \"$name\""); open = false })
                }
            }
        }
    }
}

@Composable
fun PlayersTab() {
    val st by Model.state.collectAsState()
    val arr = st?.optJSONArray("players")
    val online = (0 until (arr?.length() ?: 0)).map { arr!!.getString(it) }
    val joined = st?.optJSONObject("player_joined")
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(5000); now = System.currentTimeMillis() } }
    var tab by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    val running = st?.optString("status") == "running"
    val listOn = st?.optString("allow_list", "true") != "false"
    var allowed by remember { mutableStateOf<List<String>>(emptyList()) }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(tab, refresh) {
        if (tab == 1) {
            val r = withContext(Dispatchers.IO) { Api.get("/allowlist") }
            val a = r?.optJSONArray("names")
            allowed = (0 until (a?.length() ?: 0)).map { a!!.getString(it) }
        }
    }
    val scope = rememberCoroutineScope()
    val manage: (String) -> Unit = { c -> cmd(c); scope.launch { delay(900); refresh++ } }
    Column(Modifier.fillMaxSize()) {
        AtTabs(listOf("PLAYERS (${online.size})", "ALLOWLIST"), tab) { tab = it }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (tab == 0) {
                if (online.isEmpty()) Text("Nobody online", color = AtMuted, fontSize = 14.sp)
                online.forEach { p -> PlayerRow(p, since(now, joined?.optDouble(p, 0.0) ?: 0.0)) }
            } else {
                Panel {
                    Text(
                        if (listOn) "Allowlist is ON: only the players below can join." else "Allowlist is OFF: anyone can join. Turn it on in Settings > Players.",
                        fontSize = 13.sp, color = if (listOn) AtOrange else AtMuted
                    )
                }
                Panel {
                    Text("Allowed players (${allowed.size})", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    if (allowed.isEmpty()) Text("Nobody on the list yet.", fontSize = 13.sp, color = AtMuted, modifier = Modifier.padding(top = 6.dp))
                    allowed.forEach { n ->
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(n)
                            Spacer(Modifier.width(10.dp))
                            Text(n, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                            TextButton(enabled = running, onClick = { manage("allowlist remove \"$n\"") }) { Text("Remove", color = AtRed) }
                        }
                    }
                    if (!running) Text("Start the server to add or remove players.", fontSize = 12.sp, color = AtMuted, modifier = Modifier.padding(top = 6.dp))
                }
                Panel {
                    Text("Manage a player by name", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Player name (Xbox gamertag)") }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                        Button(enabled = running && name.isNotBlank(), onClick = { manage("allowlist add \"${name.trim()}\""); name = "" }) { Text("Allow") }
                        OutlinedButton(enabled = running && name.isNotBlank(), onClick = { manage("allowlist remove \"${name.trim()}\""); name = "" }) { Text("Unallow") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(enabled = running && name.isNotBlank(), onClick = { cmd("op \"${name.trim()}\"") }) { Text("Make OP") }
                        OutlinedButton(enabled = running && name.isNotBlank(), onClick = { cmd("deop \"${name.trim()}\"") }) { Text("Remove OP") }
                    }
                    Text("Works while the server is online. Use the exact gamertag.", fontSize = 12.sp, color = AtMuted, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

@Composable
fun ContentTab(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val st by Model.state.collectAsState()
    val running = (st?.optString("status") ?: "stopped") != "stopped"
    val levelName = st?.optString("level_name") ?: "world"
    var tab by remember { mutableIntStateOf(0) }
    var addons by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    var wmsg by remember { mutableStateOf("") }
    var wsize by remember { mutableStateOf<Long?>(null) }
    fun reload() {
        scope.launch {
            val r = withContext(Dispatchers.IO) { Api.get("/addons") }
            val a = r?.optJSONArray("addons")
            addons = (0 until (a?.length() ?: 0)).map { a!!.getJSONObject(it) }
        }
    }
    LaunchedEffect(Unit) { reload() }
    LaunchedEffect(running) { wsize = withContext(Dispatchers.IO) { Api.get("/storage")?.optLong("world") } }

    val pickAddon = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            msg = "Importing..."
            msg = withContext(Dispatchers.IO) { val f = copyToCache(ctx, uri); try { Api.upload("/addons/import", f, "addon") } finally { f.delete() } }
            reload()
        }
    }
    val pickWorld = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            wmsg = "Importing... (big worlds take a while)"
            wmsg = withContext(Dispatchers.IO) { val f = copyToCache(ctx, uri); try { Api.upload("/world/import", f, "world") } finally { f.delete() } }
        }
    }
    val exportWorld = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            wmsg = "Exporting..."
            val ok = withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri)?.use { Api.download("/world/export", it) } ?: false }
            wmsg = if (ok) "World exported." else "Export failed. Does the world exist yet?"
        }
    }

    Column(Modifier.fillMaxSize()) {
        AtTabs(listOf("WORLD", "ADDONS"), tab) { tab = it }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (tab == 0) {
                Surface(color = AtCard, contentColor = AtText, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF5B8C3A)), contentAlignment = Alignment.Center) {
                                Text("🟩", fontSize = 28.sp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(levelName, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text("Size  " + (wsize?.let { fmtSize(it) } ?: "..."), fontSize = 12.sp, color = AtMuted)
                            }
                        }
                        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PillButton("BACKUP NOW", Modifier.weight(1f), enabled = !running) { exportWorld.launch("$levelName.mcworld") }
                            PillButton("RESTORE", Modifier.weight(1f), enabled = !running) { pickWorld.launch(arrayOf("*/*")) }
                        }
                        if (running) Text("Stop the server first.", fontSize = 12.sp, color = AtOrange, modifier = Modifier.padding(top = 8.dp))
                        if (wmsg.isNotBlank()) Text(wmsg, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                Text(
                    "Backup saves a .mcworld file. Restore or upload a .mcworld file (Minecraft: Edit world > Export). " +
                        "The old world with the same name is backed up, not deleted. Stop the server first.",
                    fontSize = 12.sp, color = AtMuted
                )
                PillButton("UPLOAD NEW WORLD", Modifier.fillMaxWidth(), enabled = !running, container = AtLime) { pickWorld.launch(arrayOf("*/*")) }
                OutlinedButton(onClick = onSettings, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().height(46.dp)) {
                    Text("WORLD SETTINGS", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            } else {
                Panel {
                    Text("Import .mcpack, .mcaddon or .zip behavior/resource packs. Stop the server first, restart it after.", fontSize = 13.sp)
                    PillButton("IMPORT ADDON FILE", Modifier.padding(top = 8.dp), enabled = !running) { pickAddon.launch(arrayOf("*/*")) }
                    if (msg.isNotBlank()) Text(msg, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                }
                addons.forEach { a ->
                    Panel {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(a.optString("name"), fontWeight = FontWeight.Bold)
                                Text(a.optString("type") + " pack", fontSize = 12.sp, color = AtMuted)
                            }
                            TextButton(enabled = !running, onClick = {
                                scope.launch { withContext(Dispatchers.IO) { Api.post("/addons/remove", JSONObject().put("uuid", a.optString("uuid"))) }; reload() }
                            }) { Text("Remove") }
                        }
                    }
                }
                if (addons.isEmpty()) Text("No addons installed.", color = AtMuted, fontSize = 13.sp)
            }
        }
    }
}
