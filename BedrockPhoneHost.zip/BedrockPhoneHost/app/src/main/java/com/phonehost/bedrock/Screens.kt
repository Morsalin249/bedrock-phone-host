package com.phonehost.bedrock

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

private fun cmd(c: String) { Api.later { Api.post("/cmd", JSONObject().put("cmd", c)) } }

private fun copyToCache(ctx: Context, uri: Uri): File {
    val f = File(ctx.cacheDir, "up_" + System.nanoTime())
    ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
    return f
}

private fun battery(ctx: Context): Pair<Int, Float> {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    return (if (lvl >= 0) lvl * 100 / scale else 0) to ((i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f)
}

@Composable
private fun AddrRow(label: String, value: String?, onCopy: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 12.sp)
            Text(value ?: "not available", fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        if (value != null) TextButton(onClick = { onCopy(value) }) { Text("Copy") }
    }
}

@Composable
fun ServerTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val prefs = remember { Prefs(ctx) }
    val st by Model.state.collectAsState()
    val s = st
    if (s == null) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Loading...") }; return }

    val status = s.optString("status", "stopped")
    var version by remember { mutableStateOf(prefs.version.ifBlank { s.optString("version") }) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    var storage by remember { mutableStateOf<JSONObject?>(null) }
    LaunchedEffect(status) { storage = withContext(Dispatchers.IO) { Api.get("/storage") } }

    val (label, color) = when (status) {
        "running" -> "Online" to AtGreen
        "starting" -> "Starting..." to AtOrange
        "installing" -> "Installing..." to AtOrange
        "stopping" -> "Stopping..." to AtOrange
        else -> "Offline" to AtRed
    }
    val valid = Regex("^\\d+(\\.\\d+){2,3}$").matches(version.trim())
    val players = s.optJSONArray("players")
    val playerList = (0 until (players?.length() ?: 0)).map { players!!.getString(it) }
    val playit = s.optJSONObject("playit")
    val manual = s.optString("manual")
    val tunnel = manual.ifBlank { playit?.optString("address") ?: "" }
    val claim = playit?.optString("claim") ?: ""
    val ips = s.optJSONObject("ips")
    val v4 = ips?.optString("v4")?.takeIf { it.isNotBlank() && it != "null" }
    val v6 = ips?.optString("v6")?.takeIf { it.isNotBlank() && it != "null" }
    val started = s.optDouble("started", 0.0)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(color = color, shape = androidx.compose.foundation.shape.RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text(label, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
                val prog = s.optString("progress")
                if (prog.isNotBlank()) Text(prog, color = Color.White, fontSize = 14.sp)
                if (status == "running" && started > 0) {
                    val secs = (now / 1000 - started.toLong()).coerceAtLeast(0)
                    Text("Uptime %d:%02d:%02d".format(secs / 3600, secs % 3600 / 60, secs % 60), color = Color.White, fontSize = 14.sp)
                }
            }
        }
        Button(
            enabled = (status == "stopped" && valid) || status == "running" || status == "starting",
            colors = ButtonDefaults.buttonColors(containerColor = if (status == "stopped") AtGreen else AtRed, contentColor = Color.White),
            modifier = Modifier.fillMaxWidth().height(58.dp),
            onClick = {
                if (status == "stopped") {
                    prefs.version = version.trim()
                    scope.launch(Dispatchers.IO) { Api.post("/start", JSONObject().put("version", version.trim())) }
                } else scope.launch(Dispatchers.IO) { Api.post("/stop") }
            }
        ) { Text(if (status == "stopped") "Start" else "Stop", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        if (status == "running" || status == "starting") {
            OutlinedButton(
                modifier = Modifier.fillMaxWidth().height(50.dp),
                onClick = { scope.launch(Dispatchers.IO) { Api.post("/restart", JSONObject().put("version", version.trim())) } }
            ) { Text("Restart", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        }

        Panel {
            Text("Software", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            OutlinedTextField(
                value = version, onValueChange = { version = it }, enabled = status == "stopped", singleLine = true,
                label = { Text("Minecraft Bedrock version") }, placeholder = { Text("e.g. 1.26.52.3") },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )
            Text("Installed: " + s.optString("installed_version").ifBlank { "nothing yet" } +
                ". Players must use the same Minecraft version. The first start downloads about 300 MB.", fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        Panel {
            Text("Address", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            AddrRow("Playit (anywhere)", tunnel.ifBlank { null }) { clip.setText(AnnotatedString(it)) }
            AddrRow("Wi-Fi (same network)", v4?.let { "$it:19132" }) { clip.setText(AnnotatedString(it)) }
            AddrRow("IPv6 (direct)", v6?.let { "[$it]:19133" }) { clip.setText(AnnotatedString(it)) }
            if (claim.isNotBlank()) {
                Text("Link your Playit account, then add a Minecraft Bedrock tunnel for this agent:", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(claim))) }) { Text("Open Playit claim link") }
            }
        }
        Panel {
            Text("Players   ${playerList.size} / ${s.optString("max_players", "10")}", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            if (playerList.isEmpty()) Text("Nobody online", fontSize = 13.sp) else playerList.forEach { Text("• $it") }
        }
        Panel {
            Text("Storage", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            val sg = storage
            if (sg == null) Text("Calculating...", fontSize = 13.sp) else {
                Text("World: ${fmtSize(sg.optLong("world"))}", fontSize = 13.sp)
                Text("Server files: ${fmtSize(sg.optLong("server"))}   Linux: ${fmtSize(sg.optLong("runtime"))}", fontSize = 13.sp)
                Text("Phone free space: ${fmtSize(sg.optLong("free"))}", fontSize = 13.sp)
                if (sg.optLong("free") < 1073741824L) Text("Low space! The server may crash.", fontSize = 13.sp, color = AtRed)
            }
        }
        val (pct, temp) = remember(now / 5000) { battery(ctx) }
        Panel {
            Text("Phone", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("Battery $pct%  •  ${"%.1f".format(temp)}°C", fontSize = 13.sp)
            Text("Set Termux to 'Don't optimize' / 'No restrictions' so Android does not stop the server.", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            Row {
                TextButton(onClick = { Termux.openApp(ctx) }) { Text("Open Termux") }
                TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }) { Text("Battery settings") }
            }
        }
        Text("By installing a server you accept the Minecraft EULA (minecraft.net/eula).", fontSize = 11.sp, color = AtMuted)
    }
}

@Composable
fun ConsoleTab() {
    val logs by Model.logs.collectAsState()
    val state = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) state.scrollToItem(logs.lastIndex) }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).padding(8.dp), state = state) {
            items(logs) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFFD5DDE3)) }
        }
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("command, e.g. op Steve") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = { cmd(text); text = "" }) { Text("Send") }
        }
    }
}

@Composable
fun PlayersTab() {
    val st by Model.state.collectAsState()
    val arr = st?.optJSONArray("players")
    val online = (0 until (arr?.length() ?: 0)).map { arr!!.getString(it) }
    var name by remember { mutableStateOf("") }
    val running = st?.optString("status") == "running"
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle("Players")
        Panel {
            Text("Online now (${online.size})", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            if (online.isEmpty()) Text("Nobody online", fontSize = 13.sp)
            online.forEach { p ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(p, Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(onClick = { cmd("op \"$p\"") }) { Text("OP") }
                    TextButton(onClick = { cmd("kick \"$p\"") }) { Text("Kick") }
                }
            }
        }
        Panel {
            Text("Manage a player by name", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Player name (Xbox gamertag)") }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                Button(enabled = running && name.isNotBlank(), onClick = { cmd("allowlist add \"${name.trim()}\"") }) { Text("Allow") }
                OutlinedButton(enabled = running && name.isNotBlank(), onClick = { cmd("allowlist remove \"${name.trim()}\"") }) { Text("Unallow") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(enabled = running && name.isNotBlank(), onClick = { cmd("op \"${name.trim()}\"") }) { Text("Make OP") }
                OutlinedButton(enabled = running && name.isNotBlank(), onClick = { cmd("deop \"${name.trim()}\"") }) { Text("Remove OP") }
            }
            Text("Works while the server is online. The allowlist only matters if you turned it on in Options.", fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun ContentTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val st by Model.state.collectAsState()
    val running = (st?.optString("status") ?: "stopped") != "stopped"
    val levelName = st?.optString("level_name") ?: "world"
    var addons by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
    var msg by remember { mutableStateOf("") }
    var wmsg by remember { mutableStateOf("") }
    fun reload() {
        scope.launch {
            val r = withContext(Dispatchers.IO) { Api.get("/addons") }
            val a = r?.optJSONArray("addons")
            addons = (0 until (a?.length() ?: 0)).map { a!!.getJSONObject(it) }
        }
    }
    LaunchedEffect(Unit) { reload() }

    val pickAddon = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            msg = "Importing..."
            msg = withContext(Dispatchers.IO) { val f = copyToCache(ctx, uri); try { Api.upload("/addons/import", f, "addon") } finally { f.delete() } }
            reload()
        }
    }
    val pickWorld = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            wmsg = "Importing... (big worlds take a while)"
            wmsg = withContext(Dispatchers.IO) { val f = copyToCache(ctx, uri); try { Api.upload("/world/import", f, "world") } finally { f.delete() } }
        }
    }
    val exportWorld = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch {
            wmsg = "Exporting..."
            val ok = withContext(Dispatchers.IO) { ctx.contentResolver.openOutputStream(uri)?.use { Api.download("/world/export", it) } ?: false }
            wmsg = if (ok) "World exported." else "Export failed. Does the world exist yet?"
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle("Addons")
        Panel {
            Text("Import .mcpack, .mcaddon or .zip behavior/resource packs. Stop the server first, restart it after.", fontSize = 13.sp)
            Button(enabled = !running, onClick = { pickAddon.launch(arrayOf("*/*")) }, modifier = Modifier.padding(top = 8.dp)) { Text("Import addon file") }
            if (msg.isNotBlank()) Text(msg, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
        addons.forEach { a ->
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.optString("name"), fontWeight = FontWeight.Bold)
                        Text(a.optString("type") + " pack", fontSize = 12.sp)
                    }
                    TextButton(enabled = !running, onClick = {
                        scope.launch { withContext(Dispatchers.IO) { Api.post("/addons/remove", JSONObject().put("uuid", a.optString("uuid"))) }; reload() }
                    }) { Text("Remove") }
                }
            }
        }
        if (addons.isEmpty()) Text("No addons installed.", color = AtMuted, fontSize = 13.sp)

        SectionTitle("World")
        Panel {
            Text("Current world: $levelName", fontWeight = FontWeight.Bold)
            Text("Import a .mcworld file (Minecraft: Edit world > Export). The old world with the same name is backed up, not deleted. Stop the server first.", fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Button(enabled = !running, onClick = { pickWorld.launch(arrayOf("*/*")) }) { Text("Import world") }
                OutlinedButton(enabled = !running, onClick = { exportWorld.launch("$levelName.mcworld") }) { Text("Backup world") }
            }
            if (wmsg.isNotBlank()) Text(wmsg, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}
