package com.phonehost.bedrock

/** type: "text" | "num" | "bool" | "sel". Defaults match Bedrock Dedicated Server (phone-friendly view/tick/threads). */
data class Spec(val key: String, val label: String, val def: String, val type: String, val opts: List<String> = emptyList())

object SettingsSpec {
    private fun t(k: String, l: String, d: String) = Spec(k, l, d, "text")
    private fun n(k: String, l: String, d: String) = Spec(k, l, d, "num")
    private fun b(k: String, l: String, d: Boolean) = Spec(k, l, d.toString(), "bool")
    private fun s(k: String, l: String, d: String, o: List<String>) = Spec(k, l, d, "sel", o)

    val sections: List<Pair<String, List<Spec>>> = listOf(
        "General" to listOf(
            t("server-name", "Server name", "Dedicated Server"),
            s("gamemode", "Game mode", "survival", listOf("survival", "creative", "adventure")),
            s("difficulty", "Difficulty", "easy", listOf("peaceful", "easy", "normal", "hard")),
            n("max-players", "Max players", "10"),
            t("level-name", "World folder name", "Bedrock level"),
            t("level-seed", "World seed (empty = random)", "")
        ),
        "Rules and players" to listOf(
            b("allow-cheats", "Allow cheats / commands", false),
            b("force-gamemode", "Force game mode on join", false),
            s("default-player-permission-level", "Default player permission", "member", listOf("visitor", "member", "operator")),
            b("allow-list", "Allowlist (only listed players can join)", false),
            b("online-mode", "Require Xbox sign-in (online mode)", true),
            b("disable-player-interaction", "Disable player interaction", false),
            s("chat-restriction", "Chat restriction", "None", listOf("None", "Dropped", "Disabled")),
            b("texturepack-required", "Require resource packs", false),
            b("disable-persona", "Disable persona skins", false),
            b("disable-custom-skins", "Disable custom skins", false)
        ),
        "Performance" to listOf(
            n("view-distance", "View distance (chunks)", "6"),
            n("tick-distance", "Tick distance (4 to 12)", "4"),
            n("max-threads", "Max threads", "4"),
            n("player-idle-timeout", "Idle kick timeout (minutes, 0 = off)", "30"),
            n("compression-threshold", "Compression threshold", "1"),
            s("compression-algorithm", "Compression algorithm", "zlib", listOf("zlib", "snappy")),
            t("server-build-radius-ratio", "Build radius ratio (Disabled or 0.0 to 1.0)", "Disabled")
        ),
        "Network" to listOf(
            n("server-port", "IPv4 port", "19132"),
            n("server-portv6", "IPv6 port", "19133"),
            b("enable-lan-visibility", "Visible to LAN players", true)
        ),
        "Anti-cheat" to listOf(
            s("server-authoritative-movement", "Movement authority", "server-auth", listOf("client-auth", "server-auth", "server-auth-with-rewind")),
            b("correct-player-movement", "Correct player movement", false),
            b("server-authoritative-block-breaking", "Server-side block breaking", false),
            n("player-movement-score-threshold", "Movement score threshold", "20"),
            n("player-movement-action-direction-threshold", "Action direction threshold", "0.85"),
            n("player-movement-distance-threshold", "Distance threshold", "0.3"),
            n("player-movement-duration-threshold-in-ms", "Duration threshold (ms)", "500")
        ),
        "Advanced" to listOf(
            b("client-side-chunk-generation-enabled", "Client-side chunk generation", true),
            b("block-network-ids-are-hashes", "Block network IDs are hashes", true),
            b("content-log-file-enabled", "Write content log file", false),
            b("emit-server-telemetry", "Send server telemetry", false)
        )
    )
}
