package com.phonehost.bedrock

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

object Termux {
    const val PKG = "com.termux"
    const val PERM = "com.termux.permission.RUN_COMMAND"

    /** Paste this into Termux once so other apps may start commands. */
    const val ALLOW_COMMAND =
        "mkdir -p ~/.termux && (grep -q '^allow-external-apps' ~/.termux/termux.properties 2>/dev/null || " +
        "echo 'allow-external-apps=true' >> ~/.termux/termux.properties); termux-reload-settings"

    fun installed(ctx: Context): Boolean = try { ctx.packageManager.getPackageInfo(PKG, 0); true } catch (e: Exception) { false }

    fun hasPermission(ctx: Context): Boolean = ctx.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED

    fun openApp(ctx: Context) { ctx.packageManager.getLaunchIntentForPackage(PKG)?.let { ctx.startActivity(it) } }

    /** Sends panel.py to Termux and starts it. Returns an error message, or null if the request was sent. */
    fun startBackend(ctx: Context, token: String): String? {
        return try {
            val boot = ctx.assets.open("boot.sh").bufferedReader().use { it.readText() }
            val script = ctx.assets.open("panel.py").bufferedReader().use { it.readText() }
            val i = Intent()
            i.setClassName(PKG, "com.termux.app.RunCommandService")
            i.action = "com.termux.RUN_COMMAND"
            i.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
            i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", boot, "_", script, token))
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            null
        } catch (e: Exception) { e.message ?: "Could not reach Termux" }
    }
}
