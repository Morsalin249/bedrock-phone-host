package com.phonehost.bedrock

/** All download sources live here. If a link ever breaks, only this file needs editing. */
object Config {
    // Debian rootfs is pulled straight from the Docker Hub registry (official "debian" image, arm64).
    const val DOCKER_REPO = "library/debian"
    // Tried in order; the first one that can start a Linux shell on this phone is kept.
    val PROOT_URLS = listOf(
        "https://github.com/proot-me/proot/releases/download/v5.4.0/proot-v5.4.0-aarch64-static",
        "https://github.com/proot-me/proot/releases/download/v5.3.0/proot-v5.3.0-aarch64-static"
    )
    // Newer Debian first; the older one has an older glibc that avoids syscalls some Android versions block.
    val DOCKER_TAGS = listOf("trixie-slim", "bullseye-slim")
    const val PLAYIT_URL = "https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-linux-aarch64"
    fun bdsUrl(version: String) = "https://www.minecraft.net/bedrockdedicatedserver/bin-linux/bedrock-server-$version.zip"
    const val PORT_V4 = 19132
    const val PORT_V6 = 19133
}
