package com.phonehost.bedrock

/** All download sources live here. If a link ever breaks, only this file needs editing. */
object Config {
    // Debian rootfs is pulled straight from the Docker Hub registry (official "debian" image, arm64).
    const val DOCKER_REPO = "library/debian"
    const val DOCKER_TAG = "trixie-slim"
    const val PROOT_URL = "https://github.com/proot-me/proot/releases/download/v5.3.0/proot-v5.3.0-aarch64-static"
    const val PLAYIT_URL = "https://github.com/playit-cloud/playit-agent/releases/latest/download/playit-linux-aarch64"
    fun bdsUrl(version: String) = "https://www.minecraft.net/bedrockdedicatedserver/bin-linux/bedrock-server-$version.zip"
    const val PORT_V4 = 19132
    const val PORT_V6 = 19133
}
