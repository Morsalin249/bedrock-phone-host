package com.phonehost.bedrock

import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

/** Talks to the backend (panel.py) running inside Termux. All calls block: use from a background thread. */
object Api {
    private const val BASE = "http://127.0.0.1:8765"
    @Volatile var token = ""
    private val queue = Executors.newSingleThreadExecutor()

    /** Runs small writes (settings) in order on one background thread. */
    fun later(block: () -> Unit) { queue.execute { try { block() } catch (_: Exception) {} } }

    private fun connect(method: String, path: String): HttpURLConnection {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 2000
        c.readTimeout = 30000
        c.setRequestProperty("X-Token", token)
        return c
    }

    /** HTTP status of /ping: 200 ok, 401 wrong token, -1 not reachable. */
    fun ping(): Int = try {
        val c = connect("GET", "/ping")
        val code = c.responseCode
        c.disconnect()
        code
    } catch (e: Exception) { -1 }

    fun get(path: String): JSONObject? = try {
        val c = connect("GET", path)
        if (c.responseCode != 200) null else JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    } catch (e: Exception) { null }

    fun post(path: String, body: JSONObject = JSONObject()): JSONObject? = try {
        val c = connect("POST", path)
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        val bytes = body.toString().toByteArray()
        c.setFixedLengthStreamingMode(bytes.size)
        c.outputStream.use { it.write(bytes) }
        if (c.responseCode != 200) null else JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    } catch (e: Exception) { null }

    /** Uploads a file; returns the message the backend sent back. */
    fun upload(path: String, file: File, name: String): String = try {
        val c = connect("POST", path + "?name=" + URLEncoder.encode(name, "UTF-8"))
        c.doOutput = true
        c.readTimeout = 600000
        c.setFixedLengthStreamingMode(file.length())
        file.inputStream().use { i -> c.outputStream.use { o -> i.copyTo(o) } }
        val stream = if (c.responseCode == 200) c.inputStream else c.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        JSONObject(text).optString("message", text)
    } catch (e: Exception) { "Failed: ${e.message}" }

    fun download(path: String, out: OutputStream): Boolean = try {
        val c = connect("GET", path)
        c.readTimeout = 600000
        if (c.responseCode != 200) false else { c.inputStream.use { it.copyTo(out) }; true }
    } catch (e: Exception) { false }
}

fun fmtSize(b: Long): String = when {
    b >= 1073741824L -> "%.2f GB".format(b / 1073741824.0)
    b >= 1048576L -> "%d MB".format(b / 1048576)
    else -> "%d KB".format(b / 1024)
}
