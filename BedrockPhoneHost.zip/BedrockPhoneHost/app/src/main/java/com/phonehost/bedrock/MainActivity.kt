package com.phonehost.bedrock

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Latest data from the Termux backend. */
object Model {
    val code = MutableStateFlow(-1)
    val state = MutableStateFlow<JSONObject?>(null)
    val logs = MutableStateFlow<List<String>>(emptyList())
    @Volatile var next = 0L

    fun poll() {
        val c = Api.ping()
        code.value = c
        if (c != 200) { state.value = null; return }
        Api.get("/state")?.let { state.value = it }
        Api.get("/logs?since=$next")?.let { r ->
            val n = r.optLong("next", next)
            if (n < next) logs.value = emptyList()
            val arr = r.optJSONArray("lines")
            if (arr != null && arr.length() > 0) {
                logs.value = (logs.value + (0 until arr.length()).map { arr.getString(it) }).takeLast(700)
            }
            next = n
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Api.token = Prefs(this).token
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(primary = AtGreen, background = AtBg, surface = AtBg, onBackground = Color.White, onSurface = Color.White)
            ) {
                Surface(Modifier.fillMaxSize(), color = AtBg, contentColor = Color.White) { Root() }
            }
        }
    }
}

@Composable
fun Root() {
    val code by Model.code.collectAsState()
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            while (isActive) {
                Model.poll()
                delay(if (Model.code.value == 200) 1500L else 2000L)
            }
        }
    }
    if (code == 200) MainTabs() else SetupScreen(code)
}

@Composable
fun MainTabs() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = AtBg,
        bottomBar = {
            NavigationBar(containerColor = AtStrip) {
                listOf("🖥️" to "Server", "💻" to "Console", "👥" to "Players", "⚙️" to "Options", "📦" to "Content").forEachIndexed { i, (e, l) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(e) }, label = { Text(l, fontSize = 11.sp) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> ServerTab()
                1 -> ConsoleTab()
                2 -> PlayersTab()
                3 -> OptionsTab()
                else -> ContentTab()
            }
        }
    }
}

@Composable
fun StepCard(done: Boolean, title: String, body: String, content: @Composable ColumnScope.() -> Unit = {}) {
    Panel(Modifier.padding(vertical = 6.dp)) {
        Text((if (done) "✓  " else "○  ") + title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = if (done) Color(0xFF1E8449) else AtText)
        Text(body, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
        content()
    }
}

@Composable
fun SetupScreen(code: Int) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1500); tick++ } }
    val installed = remember(tick) { Termux.installed(ctx) }
    val perm = remember(tick) { Termux.hasPermission(ctx) }
    var msg by remember { mutableStateOf("") }
    var started by remember { mutableLongStateOf(0L) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val waited = if (started > 0) (System.currentTimeMillis() - started) / 1000 else 0L

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Bedrock Phone Host", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("The server runs inside Termux. Three quick steps connect this app to it.", color = AtMuted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp))

        StepCard(installed, "1. Termux is installed", "Install Termux from F-Droid (not the Play Store version).") {
            if (!installed) Button(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://f-droid.org/packages/com.termux/"))) }) { Text("Get Termux") }
        }
        StepCard(perm, "2. Let this app run Termux commands", "Tap Allow. If no popup appears, open Android Settings > Apps > Bedrock Phone Host > Permissions > Additional permissions.") {
            if (!perm) Button(enabled = installed, onClick = { ask.launch(Termux.PERM) }) { Text("Allow") }
        }
        StepCard(false, "3. Allow external apps in Termux (once)", "Tap Copy, open Termux, paste the line, press Enter.") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { clip.setText(AnnotatedString(Termux.ALLOW_COMMAND)) }) { Text("Copy command") }
                OutlinedButton(enabled = installed, onClick = { Termux.openApp(ctx) }) { Text("Open Termux") }
            }
        }
        StepCard(code == 200, "4. Start the backend", when (code) {
            401 -> "A backend from another install is already running. Tap Start backend again to restart it."
            else -> "Starts the control service inside Termux. The first time it may install Python (about a minute)."
        }) {
            Button(enabled = installed && perm, onClick = {
                val err = Termux.startBackend(ctx, Prefs(ctx).token)
                msg = err ?: "Request sent. Waiting for Termux..."
                started = System.currentTimeMillis()
            }) { Text("Start backend") }
            if (msg.isNotBlank()) Text(msg, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            if (started > 0 && waited > 25) {
                Text(
                    "Still waiting after ${waited}s. Check step 3 was done and that Termux is not battery-restricted. " +
                        "You can also open Termux and look at ~/bedrock-host/panel.log.",
                    fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}
