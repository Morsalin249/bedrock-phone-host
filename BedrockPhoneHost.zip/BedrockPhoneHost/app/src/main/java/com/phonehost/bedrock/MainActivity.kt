package com.phonehost.bedrock

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

private fun svc(ctx: Context, action: String, extra: Intent.() -> Unit = {}) {
    val i = Intent(ctx, ServerService::class.java).setAction(action).apply(extra)
    if (action == ServerService.START) ContextCompat.startForegroundService(ctx, i) else ctx.startService(i)
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            listOf("🏠" to "Home", "💻" to "Console", "🧩" to "Content", "⚙️" to "Settings").forEachIndexed { i, (e, l) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(e) }, label = { Text(l) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> Home(); 1 -> ConsoleTab(); 2 -> AddonsTab(); else -> SettingsTab() }
        }
    }
}

@Composable
fun Home() {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val prefs = remember { Prefs(ctx) }
    val status by ServerState.status.collectAsState()
    val players by ServerState.players.collectAsState()
    val progress by ServerState.progress.collectAsState()
    val started by ServerState.startedAt.collectAsState()
    val playit by ServerState.playitAddress.collectAsState()
    val claim by ServerState.claimUrl.collectAsState()
    var version by remember { mutableStateOf(prefs.version) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    val (v4, v6) = remember(status) { NetInfo.addresses() }
    val maxPlayers = remember(status) { prefs.propOverrides()["max-players"] ?: Props(Paths(ctx)).read()["max-players"] ?: "10" }
    val tunnel = prefs.manualAddress.ifBlank { playit }
    val valid = Regex("^\\d+(\\.\\d+){2,3}$").matches(version.trim())
    val busy = status != Status.STOPPED

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Bedrock Phone Host", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(when (status) {
                    Status.STOPPED -> "● Offline"; Status.SETTING_UP -> "● Installing"; Status.STARTING -> "● Starting"
                    Status.RUNNING -> "● Online"; Status.STOPPING -> "● Stopping"
                }, style = MaterialTheme.typography.titleMedium)
                if (progress.isNotBlank()) Text(progress, fontSize = 13.sp)
                if (status == Status.RUNNING) {
                    val s = (now - started) / 1000
                    Text("Uptime %d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60), fontSize = 13.sp)
                }
                OutlinedTextField(
                    value = version, onValueChange = { version = it; prefs.version = it.trim() },
                    label = { Text("Minecraft Bedrock version") }, placeholder = { Text("e.g. 1.21.50.07") },
                    singleLine = true, enabled = !busy, modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !busy && valid, onClick = { svc(ctx, ServerService.START) { putExtra("version", version.trim()) } }) { Text("Start") }
                    OutlinedButton(enabled = status == Status.RUNNING || status == Status.STARTING, onClick = { svc(ctx, ServerService.STOP) }) { Text("Stop") }
                }
                Text("Players must use the same Minecraft version as the server. First start downloads ~300 MB.", fontSize = 12.sp)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Join address", style = MaterialTheme.typography.titleMedium)
                AddrRow("Playit (anywhere)", tunnel.ifBlank { null }) { clip.setText(AnnotatedString(it)) }
                AddrRow("Wi-Fi (same network)", v4?.let { "$it:${Config.PORT_V4}" }) { clip.setText(AnnotatedString(it)) }
                AddrRow("IPv6 (direct)", v6?.let { "[$it]:${Config.PORT_V6}" }) { clip.setText(AnnotatedString(it)) }
                if (claim.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Link your Playit account, then create a Minecraft Bedrock tunnel for this agent:", fontSize = 12.sp)
                    TextButton(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(claim))) }) { Text("Open Playit claim link") }
                }
                Text("Android's Minecraft joins via 'Add Server' with the IP and port shown above.", fontSize = 12.sp)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Players: ${players.size} / $maxPlayers", style = MaterialTheme.typography.titleMedium)
                if (players.isEmpty()) Text("Nobody online", fontSize = 13.sp) else players.sorted().forEach { Text("• $it") }
            }
        }
        var storage by remember { mutableStateOf<Storage?>(null) }
        LaunchedEffect(status) { storage = withContext(Dispatchers.IO) { Worlds(Paths(ctx)).storage() } }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Storage", style = MaterialTheme.typography.titleMedium)
                val s = storage
                if (s == null) Text("Calculating...", fontSize = 13.sp) else {
                    Text("World: ${fmtSize(s.world)}", fontSize = 13.sp)
                    Text("App + Linux + server files: ${fmtSize(s.app)}", fontSize = 13.sp)
                    Text("Phone free space: ${fmtSize(s.free)}", fontSize = 13.sp)
                    if (s.free < 1073741824L) Text("Low space! The server may crash or corrupt the world.", fontSize = 13.sp, color = MaterialTheme.colorScheme.error)
                }
            }
        }
        val (pct, temp) = remember(now / 5000) { battery(ctx) }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Phone", style = MaterialTheme.typography.titleMedium)
                Text("Battery $pct%  •  ${"%.1f".format(temp)}°C", fontSize = 13.sp)
                TextButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
                }) { Text("Allow background running (recommended)") }
            }
        }
        Text("By installing a server you accept the Minecraft EULA (minecraft.net/eula).", fontSize = 11.sp)
    }
}

private fun battery(ctx: Context): Pair<Int, Float> {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    return (if (lvl >= 0) lvl * 100 / scale else 0) to ((i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f)
}

@Composable
fun AddrRow(label: String, value: String?, onCopy: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 12.sp)
            Text(value ?: "not available", fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        }
        if (value != null) TextButton(onClick = { onCopy(value) }) { Text("Copy") }
    }
}

@Composable
fun ConsoleTab() {
    val ctx = LocalContext.current
    val logs by ServerState.logs.collectAsState()
    val state = rememberLazyListState()
    var cmd by remember { mutableStateOf("") }
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) state.scrollToItem(logs.lastIndex) }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).padding(8.dp), state = state) {
            items(logs) { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
        }
        Row(Modifier.padding(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            OutlinedTextField(cmd, { cmd = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("command, e.g. op Steve") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = { svc(ctx, ServerService.CMD) { putExtra("cmd", cmd) }; cmd = "" }) { Text("Send") }
        }
    }
}

@Composable
fun AddonsTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val addons = remember { Addons(Paths(ctx)) }
    var items by remember { mutableStateOf(addons.list()) }
    var msg by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            msg = "Importing..."
            msg = withContext(Dispatchers.IO) { addons.import(ctx, uri) }
            items = addons.list()
        }
    }
    val worlds = remember { Worlds(Paths(ctx)) }
    var wmsg by remember { mutableStateOf("") }
    val importPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { wmsg = "Importing..."; wmsg = withContext(Dispatchers.IO) { worlds.importWorld(ctx, uri) } }
    }
    val exportPick = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) scope.launch { wmsg = "Exporting..."; wmsg = withContext(Dispatchers.IO) { worlds.exportWorld(ctx, uri) } }
    }
    val running = ServerState.status.collectAsState().value != Status.STOPPED
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Addons", style = MaterialTheme.typography.headlineSmall)
        Text("Import .mcpack, .mcaddon or .zip behavior/resource packs. Install the server first (press Start once). Restart the server after changes.", fontSize = 13.sp)
        Button(onClick = { pick.launch(arrayOf("*/*")) }) { Text("Import addon file") }
        if (msg.isNotBlank()) Text(msg, fontSize = 13.sp)
        items.forEach { a ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.name, style = MaterialTheme.typography.titleSmall)
                        Text("${a.type} pack  v${a.version.joinToString(".")}", fontSize = 12.sp)
                    }
                    TextButton(onClick = { addons.remove(a); items = addons.list() }) { Text("Remove") }
                }
            }
        }
        if (items.isEmpty()) Text("No addons installed.", fontSize = 13.sp)
        HorizontalDivider()
        Text("World", style = MaterialTheme.typography.headlineSmall)
        Text("Import a .mcworld file (in Minecraft: Edit world > Export). Stop the server first. A world with the same name is backed up, not deleted. The imported world must be from the same or an older version than the server.", fontSize = 13.sp)
        Button(enabled = !running, onClick = { importPick.launch(arrayOf("*/*")) }) { Text("Import world") }
        OutlinedButton(enabled = !running, onClick = { exportPick.launch(worlds.levelName() + ".mcworld") }) { Text("Export / back up world") }
        if (wmsg.isNotBlank()) Text(wmsg, fontSize = 13.sp)
    }
}

@Composable
fun SelectRow(label: String, value: String, options: List<String>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Box {
            OutlinedButton(onClick = { open = true }) { Text("$value  ▾") }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onPick(o); open = false }) }
            }
        }
    }
}

@Composable
fun SettingsTab() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val values = remember {
        val file = Props(Paths(ctx)).read()
        val over = prefs.propOverrides()
        mutableStateMapOf<String, String>().also { m ->
            SettingsSpec.sections.forEach { (_, specs) -> specs.forEach { sp -> m[sp.key] = over[sp.key] ?: file[sp.key] ?: sp.def } }
        }
    }
    fun set(k: String, v: String) { values[k] = v; prefs.setProp(k, v) }
    var tunnel by remember { mutableStateOf(prefs.useTunnel) }
    var secret by remember { mutableStateOf(prefs.playitSecret) }
    var manual by remember { mutableStateOf(prefs.manualAddress) }
    var limit by remember { mutableStateOf(if (prefs.worldLimitMb > 0) prefs.worldLimitMb.toString() else "") }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Text("Everything here saves automatically and is kept. Server options are applied each time you press Start.", fontSize = 12.sp)

        Text("Playit.gg tunnel", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(tunnel, { tunnel = it; prefs.useTunnel = it }); Spacer(Modifier.width(8.dp)); Text("Start tunnel with server")
        }
        OutlinedTextField(secret, { secret = it; prefs.playitSecret = it }, label = { Text("Playit secret key (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(manual, { manual = it; prefs.manualAddress = it }, label = { Text("Public address override (host:port)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Leave the secret empty to get a claim link on the Home tab. The address override must be a full address like name.gl.joinmc.link:12345, or empty.", fontSize = 12.sp)
        OutlinedTextField(limit, { limit = it.filter(Char::isDigit); prefs.worldLimitMb = limit.toIntOrNull() ?: 0 },
            label = { Text("Auto-stop if world exceeds (MB, empty = off)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())

        HorizontalDivider()
        Text("Performance profile", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Low" to listOf("5", "4", "5", "2"), "Medium" to listOf("6", "4", "10", "4"), "High" to listOf("10", "6", "20", "8")).forEach { (n, v) ->
                OutlinedButton(onClick = {
                    set("view-distance", v[0]); set("tick-distance", v[1]); set("max-players", v[2]); set("max-threads", v[3])
                }) { Text(n) }
            }
        }
        Text("Sets view distance, tick distance, max players and threads. Low suits weak phones, High suits flagships.", fontSize = 12.sp)

        SettingsSpec.sections.forEach { (title, specs) ->
            HorizontalDivider()
            Text(title, style = MaterialTheme.typography.titleMedium)
            specs.forEach { sp ->
                val v = values[sp.key] ?: sp.def
                when (sp.type) {
                    "bool" -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(sp.label, Modifier.weight(1f))
                        Switch(v == "true", { set(sp.key, if (it) "true" else "false") })
                    }
                    "sel" -> SelectRow(sp.label, v, sp.opts) { set(sp.key, it) }
                    "num" -> OutlinedTextField(v, { set(sp.key, it.filter { c -> c.isDigit() || c == '.' }) }, label = { Text(sp.label) },
                        singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    else -> OutlinedTextField(v, { set(sp.key, it) }, label = { Text(sp.label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
