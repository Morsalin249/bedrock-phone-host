package com.phonehost.bedrock

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Latest data from the Termux backend. */
object Model {
    val code = MutableStateFlow(-1)
    val state = MutableStateFlow<JSONObject?>(null)
    val logs = MutableStateFlow<List<String>>(emptyList())
    val servers = MutableStateFlow<List<JSONObject>>(emptyList())
    val versions = MutableStateFlow<JSONObject?>(null)
    @Volatile var next = 0L

    /** Makes another server the one the whole app shows and controls. */
    fun switchTo(ctx: Context, id: String) {
        Api.server = id
        Prefs(ctx).serverId = id
        state.value = null
        logs.value = emptyList()
        next = 0L
    }

    /** Preview / Latest / old versions, fetched fresh by the backend every time. */
    fun refreshVersions() { versions.value = Api.get("/versions") }

    fun poll() {
        val c = Api.ping()
        code.value = c
        if (c != 200) { state.value = null; return }
        Api.get("/servers")?.optJSONArray("servers")?.let { a ->
            val list = (0 until a.length()).map { a.getJSONObject(it) }
            servers.value = list
            if (list.isNotEmpty() && list.none { it.optString("id") == Api.server }) Api.server = list[0].optString("id")
        }
        val sid = Api.server
        Api.get("/state")?.let { if (sid == Api.server) state.value = it }
        Api.get("/logs?since=$next")?.let { r ->
            if (sid != Api.server) return@let
            val n = r.optLong("next", next)
            if (n < next) logs.value = emptyList()
            val arr = r.optJSONArray("lines")
            if (arr != null && arr.length() > 0) {
                logs.value = (logs.value + (0 until arr.length()).map { arr.getString(it) }).takeLast(700)
            }
            next = n
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Api.token = Prefs(this).token
        Api.server = Prefs(this).serverId
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = AtCyan, onPrimary = AtOnAccent, background = AtBg, surface = AtBg,
                    onBackground = AtText, onSurface = AtText, surfaceVariant = AtCard, onSurfaceVariant = AtMuted, outline = AtMuted
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = AtBg, contentColor = AtText) { Root() }
            }
        }
    }
}

@Composable
fun Root() {
    val code by Model.code.collectAsState()
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            while (isActive) {
                Model.poll()
                delay(if (Model.code.value == 200) 1500L else 2000L)
            }
        }
    }
    if (code == 200) MainTabs() else SetupScreen(code)
}

@Composable
fun MainTabs() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    var switcher by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf("") }        // "", "new", "rename", "delete"
    var nameText by remember { mutableStateOf("") }
    val servers by Model.servers.collectAsState()
    val st by Model.state.collectAsState()
    val sid = st?.optString("id") ?: ""
    val curName = st?.optString("name") ?: ""
    val curStatus = st?.optString("status") ?: "stopped"
    // every time the app opens: ask the backend for the current Preview / Latest / old versions
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { Model.refreshVersions() } }

    if (dialog == "new" || dialog == "rename") {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text(if (dialog == "new") "New server" else "Rename server") },
            text = { OutlinedTextField(nameText, { nameText = it }, singleLine = true, label = { Text("Name") }) },
            confirmButton = {
                TextButton(onClick = {
                    val n = nameText.trim(); val d = dialog; val id = sid
                    dialog = ""
                    Api.later {
                        if (d == "new") {
                            val r = Api.post("/servers/create", JSONObject().put("name", n))
                            val nid = r?.optString("id") ?: ""
                            if (nid.isNotBlank()) Model.switchTo(ctx, nid)
                        } else if (n.isNotBlank()) {
                            Api.post("/servers/rename", JSONObject().put("id", id).put("name", n))
                        }
                    }
                }) { Text(if (dialog == "new") "Create" else "Save") }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Cancel") } }
        )
    }
    if (dialog == "delete") {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text("Delete server?") },
            text = { Text("\"$curName\" and its world, add-ons and files will be deleted. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    val id = sid
                    dialog = ""
                    Api.later {
                        val r = Api.post("/servers/delete", JSONObject().put("id", id))
                        if (r?.optBoolean("ok") == true) Model.switchTo(ctx, "")
                    }
                }) { Text("Delete", color = AtRed) }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Cancel") } }
        )
    }

    Scaffold(
        containerColor = AtBg,
        topBar = {
            Surface(color = AtStrip, contentColor = AtText) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        Row(
                            Modifier.clip(RoundedCornerShape(10.dp)).clickable { switcher = true }.padding(horizontal = 4.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(curName.ifBlank { "Bedrock Phone Host" }, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("  ▾", fontSize = 18.sp, color = AtCyan)
                        }
                        DropdownMenu(expanded = switcher, onDismissRequest = { switcher = false }) {
                            servers.forEach { sv ->
                                val stt = sv.optString("status")
                                val online = sv.optInt("players")
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("● ", color = when (stt) { "running" -> AtGreen; "stopped" -> AtMuted; else -> AtOrange })
                                            Text(sv.optString("name") + "  ·  port " + sv.optString("port") + (if (online > 0) "  ·  $online online" else ""))
                                        }
                                    },
                                    onClick = { switcher = false; if (sv.optString("id") != sid) Model.switchTo(ctx, sv.optString("id")) }
                                )
                            }
                            Box(Modifier.fillMaxWidth().height(1.dp).background(AtMuted))
                            DropdownMenuItem(text = { Text("＋ New server") }, onClick = { switcher = false; nameText = ""; dialog = "new" })
                            DropdownMenuItem(text = { Text("Rename this server") }, onClick = { switcher = false; nameText = curName; dialog = "rename" })
                            DropdownMenuItem(
                                text = { Text("Delete this server", color = if (servers.size > 1 && curStatus == "stopped") AtRed else AtMuted) },
                                enabled = servers.size > 1 && curStatus == "stopped",
                                onClick = { switcher = false; dialog = "delete" }
                            )
                        }
                    }
                    Box {
                        Text("⋮", fontSize = 24.sp, modifier = Modifier.clickable { menu = true }.padding(horizontal = 10.dp))
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Open Termux") }, onClick = { menu = false; Termux.openApp(ctx) })
                            DropdownMenuItem(
                                text = { Text("Battery settings") },
                                onClick = { menu = false; ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = AtStrip) {
                listOf("🏠" to "Dashboard", "👥" to "Players", "🌍" to "Worlds", "💻" to "Console", "⚙️" to "Settings").forEachIndexed { i, (e, l) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i }, icon = { Text(e) }, label = { Text(l, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedTextColor = AtCyan, unselectedTextColor = AtMuted, indicatorColor = AtCard)
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            // a different server = a fresh screen (its own settings, version, players...)
            key(sid) {
                when (tab) {
                    0 -> ServerTab(onConsole = { tab = 3 })
                    1 -> PlayersTab()
                    2 -> ContentTab(onSettings = { tab = 4 })
                    3 -> ConsoleTab()
                    else -> OptionsTab()
                }
            }
        }
    }
}

@Composable
fun StepCard(done: Boolean, title: String, body: String, content: @Composable ColumnScope.() -> Unit = {}) {
    Panel(Modifier.padding(vertical = 6.dp)) {
        Text((if (done) "✓  " else "○  ") + title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = if (done) AtGreen else AtText)
        Text(body, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp))
        content()
    }
}

@Composable
fun SetupScreen(code: Int) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1500); tick++ } }
    val installed = remember(tick) { Termux.installed(ctx) }
    val perm = remember(tick) { Termux.hasPermission(ctx) }
    var msg by remember { mutableStateOf("") }
    var started by remember { mutableLongStateOf(0L) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val waited = if (started > 0) (System.currentTimeMillis() - started) / 1000 else 0L

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Bedrock Phone Host", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("The server runs inside Termux. Three quick steps connect this app to it.", color = AtMuted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 8.dp))

        StepCard(installed, "1. Termux is installed", "Install Termux from F-Droid (not the Play Store version).") {
            if (!installed) Button(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://f-droid.org/packages/com.termux/"))) }) { Text("Get Termux") }
        }
        StepCard(perm, "2. Let this app run Termux commands", "Tap Allow. If no popup appears, open Android Settings > Apps > Bedrock Phone Host > Permissions > Additional permissions.") {
            if (!perm) Button(enabled = installed, onClick = { ask.launch(Termux.PERM) }) { Text("Allow") }
        }
        StepCard(false, "3. Allow external apps in Termux (once)", "Tap Copy, open Termux, paste the line, press Enter.") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { clip.setText(AnnotatedString(Termux.ALLOW_COMMAND)) }) { Text("Copy command") }
                OutlinedButton(enabled = installed, onClick = { Termux.openApp(ctx) }) { Text("Open Termux") }
            }
        }
        StepCard(code == 200, "4. Start the backend", when (code) {
            401 -> "A backend from another install is already running. Tap Start backend again to restart it."
            else -> "Starts the control service inside Termux. The first time it may install Python (about a minute)."
        }) {
            Button(enabled = installed && perm, onClick = {
                val err = Termux.startBackend(ctx, Prefs(ctx).token)
                msg = err ?: "Request sent. Waiting for Termux..."
                started = System.currentTimeMillis()
            }) { Text("Start backend") }
            if (msg.isNotBlank()) Text(msg, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            if (started > 0 && waited > 25) {
                Text(
                    "Still waiting after ${waited}s. Check step 3 was done and that Termux is not battery-restricted. " +
                        "You can also open Termux and look at ~/bedrock-host/panel.log.",
                    fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}
